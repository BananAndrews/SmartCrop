// SmartCrop 1.2.1 for PixInsight - Copyright (c) 2026 BananAndrews. All rights reserved.
// Free to use. Modification, reverse engineering and redistribution of modified versions are not permitted.
#feature-id    SmartCrop : Utilities > SmartCrop
#feature-info  Synchronized automatic crop of master frames.<br/>\
   Detects black borders and noisy stacking edges on every selected image, \
   finds the largest rectangle (at any angle) with good data on all of them \
   and crops all images identically. Can register unregistered masters first \
   (by stars or by their astrometric solutions).
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/Interpolation.jsh>
!function(){var t={zeroLevel:0,noiseTol:.3,darkTolSigma:0,scanPx:300,voteRadius:5,extraMarginPx:0,allowRotation:!0,minGainPct:2};function e(e){var a={}
;for(var r in t)a[r]=t[r];if(e)for(var n in e)a[n]=e[n];return a}function a(t,e){return Math.max(2,Math.round(Math.max(t,e)/1e3))}function r(t,e){
if(void 0===e&&(e=t.length),0===e)return NaN;var a=Array.prototype.slice.call(t,0,e).sort(function(t,e){return t-e});return 1&e?a[e>>1]:.5*(a[(e>>1)-1]+a[e>>1])
}function n(t,n,i,s){s=e(s)
;for(var l=a(n,i),h=Math.ceil(n/l),c=Math.ceil(i/l),f=h*c,d=t.length,u=new Uint8Array(f),g=new Float32Array(f),w=new Float32Array(f),m=new Float32Array(n),p=new Uint8Array(n),v=new Float64Array(h),y=new Float64Array(h),x=new Int32Array(h),M=new Int32Array(h),b=0;b<c;b++){
for(var S=0;S<h;S++)v[S]=0,y[S]=0,x[S]=0,M[S]=0;for(var P=Math.min(i,(b+1)*l),C=b*l;C<P;C++){for(var A=C*n,k=0;k<n;k++){for(var B=0,_=0,z=0;z<d;z++){
var F=t[z][A+k];F>s.zeroLevel||(_=1),B+=F}m[k]=B/d,p[k]=_}for(S=0;S<h;S++){var T=S*l,R=Math.min(n,T+l),I=b*h+S;for(k=T;k<R;k++)p[k]&&(u[I]=1),v[S]+=m[k],x[S]++,
k+1<R&&(y[S]+=Math.abs(m[k+1]-m[k]),M[S]++)}}for(S=0;S<h;S++)g[I=b*h+S]=v[S]/Math.max(1,x[S]),w[I]=y[S]/Math.max(1,M[S])}
var D=new Uint8Array(f),L=new Int32Array(f),U=0,V=0;function E(t){u[t]&&!D[t]&&(D[t]=1,L[V++]=t)}for(S=0;S<h;S++)E(S),E((c-1)*h+S);for(b=0;b<c;b++)E(b*h),
E(b*h+h-1);for(;U<V;)for(var G=((j=L[U++])-(wt=j%h))/h,O=-1;O<=1;O++)for(var N=-1;N<=1;N++){var W=G+O;(mt=wt+N)>=0&&W>=0&&mt<h&&W<c&&E(W*h+mt)}
for(var H=new Float32Array(f),j=0;j<f;j++)H[j]=D[j]?0:1e9;function K(t,e){return t<0||e<0||t>=h||e>=c?0:H[e*h+t]}
for(C=0;C<c;C++)for(k=0;k<h;k++)0!==H[j=C*h+k]&&(H[j]=Math.min(H[j],K(k-1,C)+3,K(k,C-1)+3,K(k-1,C-1)+4,K(k+1,C-1)+4))
;for(C=c-1;C>=0;C--)for(k=h-1;k>=0;k--)0!==H[j=C*h+k]&&(H[j]=Math.min(H[j],K(k+1,C)+3,K(k,C+1)+3,K(k+1,C+1)+4,K(k-1,C+1)+4));var Y=new Int32Array(f)
;for(j=0;j<f;j++)Y[j]=D[j]?0:Math.max(1,Math.round(H[j]/3))
;var q=Math.max(4,Math.round(s.scanPx/l)),Q=o(g,Y,h,c,q),Z=o(w,Y,h,c,q),J=r(Array.prototype.filter.call(Z,function(t,e){return!D[e]})),X=new Uint8Array(f)
;for(j=0;j<f;j++)if(!(D[j]||Y[j]>q+s.voteRadius)){var $=Math.max(Z[j],.25*J),tt=$/1.128
;(w[j]>(1+s.noiseTol)*$||s.darkTolSigma>0&&g[j]<Q[j]-s.darkTolSigma*tt)&&(X[j]=1)}
var et=s.voteRadius,at=h+1,rt=new Int32Array(at*(c+1)),nt=new Int32Array(at*(c+1));for(C=0;C<c;C++){var ot=0,it=0;for(k=0;k<h;k++){var st=(C+1)*at+k+1
;ot+=X[j=C*h+k],it+=D[j]?0:1,rt[st]=rt[st-at]+ot,nt[st]=nt[st-at]+it}}var lt=new Uint8Array(f);for(C=0;C<c;C++)for(k=0;k<h;k++)if(!(D[j=C*h+k]||Y[j]>q)){
var ht=Math.max(0,k-et),ct=Math.min(h,k+et+1),ft=Math.max(0,C-et),dt=Math.min(c,C+et+1)
;2*(rt[dt*at+ct]-rt[ft*at+ct]-rt[dt*at+ht]+rt[ft*at+ht])>nt[dt*at+ct]-nt[ft*at+ct]-nt[dt*at+ht]+nt[ft*at+ht]&&(lt[j]=1)}var ut=new Uint8Array(f);for(U=V=0,
j=0;j<f;j++)D[j]&&(ut[j]=1,L[V++]=j);function gt(t){lt[t]&&!ut[t]&&(ut[t]=1,L[V++]=t)}for(S=0;S<h;S++)gt(S),gt((c-1)*h+S);for(b=0;b<c;b++)gt(b*h),gt(b*h+h-1)
;for(;U<V;){var wt;for(G=((j=L[U++])-(wt=j%h))/h,O=-1;O<=1;O++)for(N=-1;N<=1;N++){var mt;W=G+O,(mt=wt+N)>=0&&W>=0&&mt<h&&W<c&&gt(W*h+mt)}}
var pt=Math.ceil(s.extraMarginPx/l),vt=0,yt=0,xt=[];for(j=0;j<f;j++)ut[j]&&!D[j]&&yt++,!ut[j]&&pt>0&&Y[j]<=pt&&(ut[j]=1),ut[j]||vt++;var Mt=0
;for(j=0;j<f;j++)Mt+=D[j];var bt=0;for(j=0;j<f;j++)ut[j]&&!D[j]&&Y[j]>=q&&bt++;return bt>0&&xt.push("edge artifacts reach the "+s.scanPx+" px scan limit"),{
cell:l,gw:h,gh:c,w:n,h:i,bad:ut,goodFrac:vt/f,noDataFrac:Mt/f,artifactFrac:yt/f,noiseRef:J,notes:xt,outside:D}}function o(t,e,a,n,o){
for(var s=Math.max(8,Math.round(Math.max(a,n)/24)),l=[],h=0;h<n;h+=s)for(var c=0;c<a;c+=s){
for(var f=[],d=h;d<Math.min(n,h+s);d++)for(var u=c;u<Math.min(a,c+s);u++)e[C=d*a+u]>o&&f.push(t[C]);f.length>=s*s/2&&l.push({x:2*(c+s/2)/a-1,y:2*(h+s/2)/n-1,
v:r(f)})}function g(t,e){return[1,t,e,t*t,t*e,e*e]}for(var w=null,m=l,p=0;p<4&&!(m.length<10);p++){
for(var v=[],y=[0,0,0,0,0,0],x=0;x<6;x++)v.push([0,0,0,0,0,0]);m.forEach(function(t){for(var e=g(t.x,t.y),a=0;a<6;a++){y[a]+=e[a]*t.v
;for(var r=0;r<6;r++)v[a][r]+=e[a]*e[r]}}),w=i(v,y);var M=l.map(function(t){for(var e=g(t.x,t.y),a=0,r=0;r<6;r++)a+=w[r]*e[r];return t.v-a
}),b=1.4826*r(M.map(Math.abs))+1e-30;m=l.filter(function(t,e){return Math.abs(M[e])<3*b})}var S=new Float32Array(a*n);if(!w){
for(var P=r(l.length?l.map(function(t){return t.v}):[0]),C=0;C<S.length;C++)S[C]=P;return S}for(d=0;d<n;d++)for(u=0;u<a;u++){
var A=g(2*(u+.5)/a-1,2*(d+.5)/n-1),k=0;for(x=0;x<6;x++)k+=w[x]*A[x];S[d*a+u]=k}return S}function i(t,e){for(var a=e.length,r=t.map(function(t,a){
return t.concat([e[a]])}),n=0;n<a;n++){for(var o=n,i=n+1;i<a;i++)Math.abs(r[i][n])>Math.abs(r[o][n])&&(o=i);var s=r[n];if(r[n]=r[o],r[o]=s,
!(Math.abs(r[n][n])<1e-300))for(i=n+1;i<a;i++)for(var l=r[i][n]/r[n][n],h=n;h<=a;h++)r[i][h]-=l*r[n][h]}var c=[];for(i=0;i<a;i++)c.push(0);for(i=a-1;i>=0;i--){
var f=r[i][a];for(h=i+1;h<a;h++)f-=r[i][h]*c[h];c[i]=Math.abs(r[i][i])<1e-300?0:f/r[i][i]}return c}function s(t,e,a){
for(var r=new Int32Array(e),n=new Int32Array(e+1),o={area:0,x0:0,y0:0,x1:0,y1:0},i=0;i<a;i++){for(var s=i*e,l=0;l<e;l++)r[l]=t[s+l]?r[l]+1:0;var h=0
;for(l=0;l<=e;l++){for(var c=l<e?r[l]:0;h>0&&r[n[h-1]]>=c;){var f=r[n[--h]],d=h>0?n[h-1]+1:0,u=f*(l-d);u>o.area&&(o={area:u,x0:d,y0:i-f+1,x1:l,y1:i+1})}n[h++]=l
}}return o}function l(t,e,a,r){if(0===r)return{area:(v=s(t,e,a)).area,cx:(v.x0+v.x1)/2,cy:(v.y0+v.y1)/2,w:v.x1-v.x0,h:v.y1-v.y0,angle:0,axis:v}
;for(var n=Math.cos(r),o=Math.sin(r),i=Math.ceil(e*Math.abs(n)+a*Math.abs(o)),l=Math.ceil(e*Math.abs(o)+a*Math.abs(n)),h=new Uint8Array(i*l),c=e/2,f=a/2,d=0;d<l;d++)for(var u=d+.5-l/2,g=0;g<i;g++){
var w=g+.5-i/2,m=Math.floor(c+w*n-u*o),p=Math.floor(f+w*o+u*n);m>=0&&p>=0&&m<e&&p<a&&(h[d*i+g]=t[p*e+m])}var v;return w=((v=s(h,i,l)).x0+v.x1)/2-i/2,
u=(v.y0+v.y1)/2-l/2,{area:v.area,cx:c+w*n-u*o,cy:f+w*o+u*n,w:v.x1-v.x0,h:v.y1-v.y0,angle:r}}function h(t,e,a,r){
for(var n=Math.floor(e/r),o=Math.floor(a/r),i=new Uint8Array(n*o),s=0;s<o;s++)for(var l=0;l<n;l++){
for(var h=1,c=0;c<r&&h;c++)for(var f=0;f<r;f++)if(!t[(s*r+c)*e+l*r+f]){h=0;break}i[s*n+l]=h}return{g:i,w:n,h:o}}function c(t,e,a,r){
for(var n=[],o=[],i=2;i<a-2;i++)for(var s=2;s<e-2;s++)!t[v=i*e+s]||t[v-1]&&t[v+1]&&t[v-e]&&t[v+e]||(n.push(s),o.push(i));var l=n.length;if(l<20)return null
;if(l>6e3){for(var h=l/6e3,c=[],f=[],d=0;d<l;d+=h)c.push(n[Math.floor(d)]),f.push(o[Math.floor(d)]);o=f,l=(n=c).length}
var u=Math.ceil(Math.sqrt(e*e+a*a))+2,g=new Float64Array(2*u+1);function w(t){for(var e=t*Math.PI/180,a=Math.cos(e),r=Math.sin(e),i=0,s=0;s<2;s++){
for(var h=0;h<g.length;h++)g[h]=0;for(h=0;h<l;h++){var c=0===s?n[h]*a+o[h]*r:-n[h]*r+o[h]*a;g[Math.round(c/2)+u]++}for(h=0;h<g.length;h++)i+=g[h]*g[h]}return i}
var m=0,p=-1;if(r&&r.length){for(var v=0;v<r.length;v++)(M=w(r[v]))>p&&(p=M,m=r[v]);return m=(m%90+135)%90-45,Math.round(100*m)/100}
for(var y=-45;y<45;y+=.5)(M=w(y))>p&&(p=M,m=y);var x=m;for(y=x-.5;y<=x+.5+1e-9;y+=.05){var M;(M=w(y))>p&&(p=M,m=y)}
return(m=Math.round(100*m)/100)>=45?m-90:m<-45?m+90:m}var f="SmartCrop",d="1.2.1",u="SmartCrop",g={noiseTolPct:30,scanPx:300,extraMarginPx:0,allowRotation:!0,
minGainPct:2};function w(){Settings.write(u+"/noiseTolPct",DataType_Double,g.noiseTolPct),Settings.write(u+"/scanPx",DataType_Int32,g.scanPx),
Settings.write(u+"/extraMarginPx",DataType_Int32,g.extraMarginPx),Settings.write(u+"/allowRotation",DataType_Boolean,g.allowRotation),
Settings.write(u+"/minGainPct",DataType_Double,g.minGainPct)}function m(){return{noiseTol:g.noiseTolPct/100,scanPx:g.scanPx,extraMarginPx:g.extraMarginPx,
allowRotation:g.allowRotation,minGainPct:g.minGainPct}}function p(t,e,a,r){if(e.rotated){
var n=e.angleDeg*Math.PI/180,o=Math.abs(Math.cos(n)),i=Math.abs(Math.sin(n)),s=Math.floor(e.width),l=Math.floor(e.height),h=Math.max(s/2,s/2*o+l/2*i),c=Math.max(l/2,s/2*i+l/2*o),f=Math.floor(e.cx-h-8),d=Math.floor(e.cy-c-8),u=Math.ceil(e.cx+h+8),g=Math.ceil(e.cy+c+8)
;t.cropTo(f,d,u,g,r);var w=e.cx-f,m=e.cy-d;t.rotate(a*n,w,m,r);var p=Math.round(w-s/2),v=Math.round(m-l/2);t.cropTo(p,v,p+s,v+l,r)
}else t.cropTo(e.x0,e.y0,e.x1,e.y1,r)}function v(t){
for(var e=t.w,a=t.h,r=t.cell,n=new Float32Array(e*a),o=0;o<a;o++)for(var i=Math.floor(o/r)*t.gw,s=o*e,l=0;l<e;l++)n[s+l]=t.bad[i+Math.floor(l/r)]
;var h=new Image(e,a,1,ColorSpace_Gray);return h.setSamples(n,new Rect(0,0,e,a),0),h}function y(t,e){
var a=t.image,r=new ImageWindow(a.width,a.height,a.numberOfChannels,32,!0,a.isColor,e);return r.mainView.beginProcess(UndoFlag_NoSwapFile),
r.mainView.image.assign(a),r.mainView.endProcess(),t.window.hasAstrometricSolution&&r.copyAstrometricSolution(t.window),r}function x(t,e,a){
for(var r={},n=ImageWindow.windows,o=0;o<n.length;o++)r[n[o].mainView.id]=!0;var i=new StarAlignment;i.referenceImage=e.id,i.referenceIsFile=!1;try{
i.noGUIMessages=!0}catch(t){}var s=!1;try{s=i.executeOn(t,!1)}catch(t){s=!1}if(a){a.angle=null;try{var l=i.outputData,h=l&&l.length?l[l.length-1]:null
;h&&isFinite(h[11])&&isFinite(h[14])&&(0!==h[11]||0!==h[14])&&(a.angle=180*Math.atan2(h[14],h[11])/Math.PI)}catch(t){}}var c=null;for(n=ImageWindow.windows,
o=0;o<n.length;o++){var f=n[o].mainView.id;r[f]||n[o].isNull||c&&0!==f.indexOf(t.id)||(c=n[o])}if(!c)return!1
;var d=s&&c.mainView.image.width===e.image.width&&c.mainView.image.height===e.image.height;if(d){
t.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{t.image.assign(c.mainView.image)}finally{t.endProcess()}
e.window.hasAstrometricSolution&&t.window.copyAstrometricSolution(e.window)}return c.forceClose(),d}function M(t,e,a){var r=null;try{r=t.imageToCelestial(e,a)
}catch(n){try{r=t.imageToCelestial(new Point(e,a))}catch(t){r=null}}return r&&isFinite(r.x)&&isFinite(r.y)?r:null}function b(t,e,a){var r=null;try{
r=t.celestialToImage(e,a)}catch(n){try{r=t.celestialToImage(new Point(e,a))}catch(t){r=null}}return r&&isFinite(r.x)&&isFinite(r.y)?r:null}
function S(t,e,a,r,n){for(var o=t.mainView.image,i=o.width,s=o.height,l=[],h=[[0,0,i,0],[i,0,i,s],[i,s,0,s],[0,s,0,0]],c=0;c<4;c++)for(var f=0;f<32;f++){
var d=f/32,u=M(t,h[c][0]+d*(h[c][2]-h[c][0]),h[c][1]+d*(h[c][3]-h[c][1])),g=u?b(e,u.x,u.y):null
;if(!g)throw new Error("Cannot map "+t.mainView.id+" onto "+e.mainView.id+" with the astrometric solutions.");l.push({x:g.x/n,y:g.y/n})}return function(t,e,a){
for(var r=new Uint8Array(e*a),n=t.length,o=0;o<a;o++){for(var i=o+.5,s=[],l=0;l<n;l++){var h=t[l],c=t[(l+1)%n]
;h.y<=i!=c.y<=i&&s.push(h.x+(i-h.y)*(c.x-h.x)/(c.y-h.y))}s.sort(function(t,e){return t-e})
;for(var f=0;f+1<s.length;f+=2)for(var d=Math.max(0,Math.ceil(s[f]-.5)),u=Math.min(e-1,Math.floor(s[f+1]-.5)),g=d;g<=u;g++)r[o*e+g]=1}return r}(l,a,r)}
function P(t,e){var a=t.mainView.image,r=a.width/2,n=a.height/2,o=M(t,r,n),i=M(t,r+100,n),s=o?b(e,o.x,o.y):null,l=i?b(e,i.x,i.y):null
;return s&&l?180*Math.atan2(l.y-s.y,l.x-s.x)/Math.PI:null}function C(t,e){
var a=e.image,r=t.image.numberOfChannels,n=null,o=new ImageWindow(a.width,a.height,r,32,!0,r>=3,"SmartCrop_reproject");try{o.copyAstrometricSolution(e.window)
;for(var i=[function(){o.astrometricReprojection(t.window,new Point(0,0),!0)},function(){o.astrometricReprojection(t.window)},function(){
o.astrometricReprojection(t.window,new Point(0,0))}],s=0;s<i.length&&!n;s++)try{i[s]();var l=o.mainView.image
;l.width===a.width&&l.height===a.height&&l.maximum()>0&&(n=new Image(l))}catch(t){}}finally{o.forceClose()}
if(n||(console.writeln("   (resampling "+t.id+" through the astrometric solutions)"),n=function(t,e){
for(var a=t.image,r=e.image,n=r.width,o=r.height,i=a.width,s=a.height,l=a.numberOfChannels,h=32,c=Math.ceil(n/h)+1,f=Math.ceil(o/h)+1,d=new Float64Array(c*f),u=new Float64Array(c*f),g=new Uint8Array(c*f),w=0;w<f;w++)for(var m=0;m<c;m++){
var p=M(e.window,m*h+.5,w*h+.5),v=p?b(t.window,p.x,p.y):null;v&&(d[w*c+m]=v.x-.5,u[w*c+m]=v.y-.5,g[w*c+m]=1)}
for(var y=A(a),x=[],S=0;S<l;S++)x.push(new Float32Array(n*o));function P(t,e,a,r,n){return a+.5*t*(r-e+t*(2*e-5*a+4*r-n+t*(3*(a-r)+n-e)))}for(var C=0;C<o;C++){
255&C||processEvents();for(var k=C/h,B=Math.min(f-2,Math.floor(k)),_=k-B,z=0;z<n;z++){var F=z/h,T=Math.min(c-2,Math.floor(F)),R=F-T,I=B*c+T,D=I+1,L=I+c,U=L+1
;if(g[I]&&g[D]&&g[L]&&g[U]){
var V=(d[I]*(1-R)+d[D]*R)*(1-_)+(d[L]*(1-R)+d[U]*R)*_,E=(u[I]*(1-R)+u[D]*R)*(1-_)+(u[L]*(1-R)+u[U]*R)*_,G=Math.floor(V),O=Math.floor(E)
;if(!(G<1||O<1||G>i-3||O>s-3)){var N=V-G,W=E-O,H=C*n+z;for(S=0;S<l;S++){for(var j=y[S],K=(O-1)*i+G-1,Y=[],q=0;q<4;q++,
K+=i)Y.push(P(N,j[K],j[K+1],j[K+2],j[K+3]))
;var Q=P(W,Y[0],Y[1],Y[2],Y[3]),Z=O*i+G,J=Math.min(j[Z],j[Z+1],j[Z+i],j[Z+i+1]),X=Math.max(j[Z],j[Z+1],j[Z+i],j[Z+i+1]);x[S][H]=Q<J?J:Q>X?X:Q}}}}}y=null
;var $=new Image(n,o,l,l>=3?ColorSpace_RGB:ColorSpace_Gray);for(S=0;S<l;S++)$.setSamples(x[S],new Rect(0,0,n,o),S);return $}(t,e)),!n)return!1
;t.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{t.image.assign(n)}finally{t.endProcess()}return n.free(),
t.window.copyAstrometricSolution(e.window),t.image.width===a.width&&t.image.height===a.height}function A(t){
for(var e=[],a=0;a<t.numberOfChannels;a++)e.push(t.toFloat32Array(new Rect(0,0,t.width,t.height),a));return e}function k(t){this.__base__=Control,
this.__base__(t);var e=this;function a(){var t=e.data,a=function(){var t=e.data,a=t.bitmap.width,r=t.bitmap.height;return Math.min(e.width/a,e.height/r)
}()*e.zoom;return{k:a,tx:(e.width-t.bitmap.width*a)/2+e.ox,ty:(e.height-t.bitmap.height*a)/2+e.oy}}this.data=null,this.zoom=1,this.ox=0,this.oy=0,
this.drag=null,this.setScaledMinSize(420,420),this.toolTip="<p>Mouse wheel: zoom &nbsp; Drag: pan &nbsp; Double click: fit</p>",this.onPaint=function(){
var t=new Graphics(this);if(t.fillRect(0,0,this.width,this.height,new Brush(4280295456)),!e.data)return t.pen=new Pen(4288716960),
t.drawTextRect(0,0,this.width,this.height,"Press Analyze to see the crop",TextAlign_Center|TextAlign_VertCenter),void t.end();var r=a(),n=e.data
;t.translateTransformation(r.tx,r.ty),t.scaleTransformation(r.k),t.drawBitmap(0,0,n.bitmap),t.resetTransformation(),t.antialiasing=!0,
t.pen=new Pen(4294956032,2);for(var o=0;o<4;o++){var i=n.corners[o],s=n.corners[(o+1)%4]
;t.drawLine(r.tx+r.k*i.x/n.scale,r.ty+r.k*i.y/n.scale,r.tx+r.k*s.x/n.scale,r.ty+r.k*s.y/n.scale)}t.end()},this.onMouseWheel=function(t,r,n){if(e.data){
var o=a(),i=(t-o.tx)/o.k,s=(r-o.ty)/o.k;if(e.zoom=Math.max(1,Math.min(32,e.zoom*(n>0?1.25:.8))),1===e.zoom)e.ox=e.oy=0;else{var l=a();e.ox+=t-(l.tx+i*l.k),
e.oy+=r-(l.ty+s*l.k)}e.update()}},this.onMousePress=function(t,a){e.drag={x:t,y:a,ox:e.ox,oy:e.oy}},this.onMouseMove=function(t,a){
e.drag&&(e.ox=e.drag.ox+t-e.drag.x,e.oy=e.drag.oy+a-e.drag.y,e.update())},this.onMouseRelease=function(){e.drag=null},this.onMouseDoubleClick=function(){
e.zoom=1,e.ox=e.oy=0,e.update()},this.onResize=function(){e.update()}}function B(t){
for(var e=t.keywords,a=t.mainView.image,r=0;r<e.length;r++)if("HISTORY"===e[r].name){var n=/SmartCrop [^:]*: (\d+)x(\d+) crop/.exec(e[r].comment+" "+e[r].value)
;if(n&&+n[1]===a.width&&+n[2]===a.height)return!0}return!1}function _(){this.__base__=Dialog,this.__base__();var t=this;this.analysis=null
;var e=this.font.width("Max rotation angle (\xb0):")+8;this.helpLabel=new Label(this),this.helpLabel.frameStyle=FrameStyle_Box,this.helpLabel.margin=6,
this.helpLabel.wordWrapping=!0,
this.helpLabel.useRichText=!0,this.helpLabel.text="<b>"+f+" v"+d+"</b> &mdash; tick the masters to crop. The script finds black borders and noisy stacking edges on each of them, builds the largest rectangle that is clean on <i>all</i> of them (at any angle, if rotating keeps more of the field) and crops every ticked image identically. Masters that are not registered to each other can be registered first (untick the box below). Every step can be undone (Ctrl+Z).",
this.tree=new TreeBox(this),this.tree.numberOfColumns=3,this.tree.headerVisible=!0,this.tree.setHeaderText(0,"Image"),this.tree.setHeaderText(1,"Size"),
this.tree.setHeaderText(2,"Channels"),this.tree.rootDecoration=!1,this.tree.alternateRowColor=!0,this.tree.setScaledMinSize(480,200)
;for(var a=ImageWindow.openWindows,r=0;r<a.length;r++)if(!a[r].isNull&&(a[r].visible||a[r].iconic)){var n=a[r].mainView
;if(!n.isNull&&0!==n.id.indexOf("SmartCrop_preview")){var o=new TreeBoxNode(this.tree);o.checkable=!0,o.checked=!0,o.setText(0,n.id),
o.setText(1,n.image.width+" x "+n.image.height),o.setText(2,n.image.isColor?"RGB":"Gray"),o.viewId=n.id}}
for(var i=0;i<3;i++)this.tree.adjustColumnWidthToContents(i);function s(a,r,n,o,i,s,l){var h=new NumericControl(t);return h.label.text=a,h.label.minWidth=e,
h.setRange(r,n),h.slider.setRange(0,Math.round((n-r)*Math.pow(10,Math.min(o,1)))),h.slider.scaledMinWidth=200,h.setPrecision(o),h.setValue(i),h.toolTip=s,
h.onValueUpdated=function(e){l(e),t.invalidate()},h}this.tree.onNodeUpdated=function(){t.invalidate()},this.allButton=new PushButton(this),
this.allButton.text="Select all",this.allButton.onClick=function(){t.setAll(!0)},this.noneButton=new PushButton(this),this.noneButton.text="Select none",
this.noneButton.onClick=function(){t.setAll(!1)},this.listButtons=new HorizontalSizer,this.listButtons.spacing=6,this.listButtons.add(this.allButton),
this.listButtons.add(this.noneButton),this.listButtons.addStretch(),this.regCheck=new CheckBox(this),
this.regCheck.text="Images are already registered to each other",this.regCheck.checked=!0,
this.regCheck.toolTip="<p>Untick for masters that were stacked separately (other software, other nights, other cameras): SmartCrop registers them first - by stars, or by their astrometric solutions when star matching fails - to the image that gives the largest common crop. Registration is an undoable step on each image.</p>",
this.regCheck.onCheck=function(){t.invalidate()
},this.noiseCtl=s("Edge noise tolerance (%):",5,200,0,g.noiseTolPct,"<p>Edges whose noise exceeds the interior noise by more than this are cut off (areas covered by fewer subframes). Lower = stricter crop.</p>",function(t){
g.noiseTolPct=t
}),this.scanCtl=s("Max edge depth (px):",20,1e3,0,g.scanPx,"<p>Noisy edges are searched for no deeper than this from the data border.</p>",function(t){
g.scanPx=Math.round(t)}),this.marginCtl=s("Extra margin (px):",0,200,0,g.extraMarginPx,"<p>Additional safety margin cut from the usable area.</p>",function(t){
g.extraMarginPx=Math.round(t)}),this.rotCheck=new CheckBox(this),this.rotCheck.text="Allow rotated crop",this.rotCheck.checked=g.allowRotation,
this.rotCheck.toolTip="<p>Rotate the crop rectangle (and the images) when this keeps noticeably more of the field.</p>",this.rotCheck.onCheck=function(e){
g.allowRotation=e,t.gainCtl.enabled=e,t.invalidate()
},this.gainCtl=s("Min area gain (%):",0,20,1,g.minGainPct,"<p>Rotate only if the rotated crop is at least this much larger than the best axis-aligned one (rotation resamples the images).</p>",function(t){
g.minGainPct=t}),this.gainCtl.enabled=g.allowRotation,this.paramBox=new GroupBox(this),this.paramBox.title="Parameters",this.paramBox.sizer=new VerticalSizer,
this.paramBox.sizer.margin=6,this.paramBox.sizer.spacing=4,this.paramBox.sizer.add(this.noiseCtl),this.paramBox.sizer.add(this.scanCtl),
this.paramBox.sizer.add(this.marginCtl),this.paramBox.sizer.add(this.rotCheck),this.paramBox.sizer.add(this.gainCtl),this.resultLabel=new Label(this),
this.resultLabel.frameStyle=FrameStyle_Sunken,this.resultLabel.margin=6,this.resultLabel.wordWrapping=!0,
this.resultLabel.text="Press Analyze to compute the crop.",this.resultLabel.setScaledMinHeight(48),this.analyzeButton=new PushButton(this),
this.analyzeButton.text="Analyze",this.analyzeButton.icon=this.scaledResource(":/icons/find.png"),this.analyzeButton.onClick=function(){t.analyze()},
this.applyButton=new PushButton(this),this.applyButton.text="Crop",this.applyButton.icon=this.scaledResource(":/icons/ok.png"),
this.applyButton.toolTip="<p>Crop all ticked images (analyzes first if needed).</p>",this.applyButton.onClick=function(){t.apply()},
this.closeButton=new PushButton(this),this.closeButton.text="Close",this.closeButton.icon=this.scaledResource(":/icons/close.png"),
this.closeButton.onClick=function(){t.cancel()},this.heartLabel=new Label(this),this.heartLabel.useRichText=!0,
this.heartLabel.text='<span style="color:#e0245e; font-size:15pt;">&#9829;</span>',
this.heartLabel.toolTip="<p>Like SmartCrop? Support its development with a donation (PayPal).</p>",this.heartLabel.cursor=new Cursor(StdCursor_PointingHand),
this.heartLabel.onMousePress=function(){
Dialog.openBrowser("https://www.paypal.com/donate/?business=contact%40bluebelleweddings.com&no_recurring=0&item_name=SmartCrop")},
this.buttons=new HorizontalSizer,this.buttons.spacing=6,this.buttons.add(this.heartLabel),this.buttons.addStretch(),this.buttons.add(this.analyzeButton),
this.buttons.add(this.applyButton),this.buttons.add(this.closeButton),this.preview=new k(this),this.leftSizer=new VerticalSizer,this.leftSizer.spacing=6,
this.leftSizer.add(this.helpLabel),this.leftSizer.add(this.tree,100),this.leftSizer.add(this.listButtons),this.leftSizer.add(this.regCheck),
this.leftSizer.add(this.paramBox),this.leftSizer.add(this.resultLabel),this.leftSizer.add(this.buttons),this.sizer=new HorizontalSizer,this.sizer.margin=8,
this.sizer.spacing=8,this.sizer.add(this.leftSizer),this.sizer.add(this.preview,100),this.windowTitle=f+" v"+d,this.adjustToContents(),
this.setScaledMinSize(1e3,620)}k.prototype=new Control,k.prototype.setData=function(t){this.data=t,this.zoom=1,this.ox=this.oy=0,this.update()},
_.prototype=new Dialog,_.prototype.setAll=function(t){for(var e=0;e<this.tree.numberOfChildren;e++)this.tree.child(e).checked=t;this.invalidate()},
_.prototype.invalidate=function(){this.analysis&&(this.resultLabel.text="Parameters or selection changed - press Analyze again.",this.preview.setData(null)),
this.analysis=null},_.prototype.selectedViews=function(){for(var t=[],e=0;e<this.tree.numberOfChildren;e++){var a=this.tree.child(e);if(a.checked){
var r=View.viewById(a.viewId);r&&!r.isNull&&t.push(r)}}return t},_.prototype.analyze=function(){var t=this.selectedViews()
;if(0===t.length)return new MessageBox("Tick at least one image.",f,StdIcon_Warning,StdButton_Ok).execute(),!1
;for(var o,i,s,u=[],w=0;w<t.length;w++)B(t[w].window)&&u.push(t[w].id)
;if(u.length>0&&new MessageBox("Already cropped by SmartCrop:\n   "+u.join("\n   ")+"\n\nAnalyze again anyway? A second pass may trim the edges a little more.",f,StdIcon_Question,StdButton_Yes,StdButton_No).execute()!==StdButton_Yes)return!1
;this.enabled=!1,console.show(),console.abortEnabled=!0;try{console.noteln("<end><cbr><br>"+f+" v"+d+": "+t.length+" image(s)");var M=Date.now()
;!this.regCheck.checked&&t.length>1&&(function(t){if(!(t.length<2)){for(var e=!0,r=0;r<t.length;r++)t[r].window.hasAstrometricSolution||(e=!1)
;var o=t[0],i=o.image.width,s=o.image.height,f=a(i,s),d=Math.ceil(i/f),u=Math.ceil(s/f)
;console.noteln("<end><cbr>Registration: estimating frame positions relative to "+o.id);var g=n(A(o.image),i,s,m()),w=new Uint8Array(d*u)
;for(r=0;r<w.length;r++)w[r]=g.outside[r]?0:1;var p=[w],v=[null],M=["reference"],b=[null];try{for(var k=1;k<t.length;k++){processEvents()
;var B=y(t[k],"SmartCrop_tmp"+k);v.push(B);var _={};if(x(B.mainView,o,_)){var z=n(A(B.mainView.image),i,s,m()),F=new Uint8Array(d*u)
;for(r=0;r<F.length;r++)F[r]=z.outside[r]?0:1;p.push(F),M.push("stars"),b.push(null===_.angle?null:[_.angle,-_.angle])}else{
if(!e)throw new Error("Could not register "+t[k].id+" to "+o.id+" by stars, and not all images are plate-solved (astrometric registration needs a solution on every image).")
;B.forceClose(),v[k]=null,p.push(S(t[k].window,o.window,d,u,f)),M.push("astrometry");var T=P(t[k].window,o.window);b.push(null===T?null:[T])}
console.writeln("   "+t[k].id+": "+M[k]+(b[k]?format(", rotation %.2f\xb0",b[k][0]):", rotation from the frame edges"))}var R=function(t,e,a,r){
for(var n=Math.max(1,Math.round(Math.max(e,a)/250)),o=new Uint8Array(e*a),i=0;i<o.length;i++){for(var s=1,f=0;f<t.length&&s;f++)t[f][i]||(s=0);o[i]=s}
var d=h(o,e,a,n),u=d.w*d.h,g=function(t,e,a){var r=Math.PI/180,n={area:-1,angleDeg:0};function o(o){var i=l(t,e,a,0===o?0:o*r);i.area>n.area&&(n={area:i.area,
angleDeg:o})}for(var i=-45;i<=45+1e-9;i+=1)o(Math.round(100*i)/100);var s=n.angleDeg
;for(i=Math.max(-45,s-1);i<=Math.min(45,s+1)+1e-9;i+=.1)o(Math.round(100*i)/100);return n}(d.g,d.w,d.h),w={index:0,cropAngle:g.angleDeg,areaFrac:g.area/u,
orientations:[],rotations:[]};for(f=0;f<t.length;f++){var m=0===f?0:c(t[f],e,a,r&&r[f]);null===m&&(m=0);var p=Math.abs(((g.angleDeg-m)%90+135)%90-45)
;w.orientations.push(m),w.rotations.push(p),p<w.rotations[w.index]-.05&&(w.index=f)}return w}(p,d,u,b)
;for(console.writeln(format("   best common crop: %.1f%% of the frame at %+.2f\xb0",100*R.areaFrac,R.cropAngle)),
k=0;k<t.length;k++)console.writeln(format("   %-28s tilt %+6.2f\xb0, needs %5.2f\xb0 of crop rotation as reference%s",t[k].id,R.orientations[k],R.rotations[k],k===R.index?"   <- chosen":""))
;var I=t[R.index];for(console.noteln("Registering to "+I.id),k=0;k<t.length;k++)if(k!==R.index){processEvents();var D=t[k],L=!1;if(0===R.index&&v[k]){
D.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{D.image.assign(v[k].mainView.image)}finally{D.endProcess()}L=!0}
if(L||"astrometry"===M[k]||(L=x(D,I)),!L&&e&&(L=C(D,I)),!L)throw new Error("Could not register "+D.id+" to "+I.id+".");console.writeln("   "+D.id+" registered")
}}finally{for(k=0;k<v.length;k++)v[k]&&!v[k].isNull&&v[k].forceClose()}}}(t),this.regCheck.checked=!0),this.analysis=function(t){
for(var a=m(),r=[],o=t[0].image.width,i=t[0].image.height,s=0;s<t.length;s++){var c=t[s].image
;if(c.width!==o||c.height!==i)throw new Error(t[s].id+" is "+c.width+"x"+c.height+", but "+t[0].id+" is "+o+"x"+i+'. The images are not registered to each other - untick "Images are already registered" to let SmartCrop register them.')
}for(s=0;s<t.length;s++){var f=Date.now();console.write("<end><cbr>Analyzing "+t[s].id+" ... "),processEvents();var d=n(A(t[s].image),o,i,a);d.id=t[s].id,
console.writeln(format("good %.1f%% (no data %.1f%%, noisy edges %.1f%%)  %.1f s",100*d.goodFrac,100*d.noDataFrac,100*d.artifactFrac,(Date.now()-f)/1e3))
;for(var u=0;u<d.notes.length;u++)console.warningln("   ** "+d.notes[u]);r.push(d),processEvents(),gc()}var g=function(t){
for(var e=t[0],a=new Uint8Array(e.bad.length),r=0;r<t.length;r++){var n=t[r];if(n.w!==e.w||n.h!==e.h)throw new Error("Images have different dimensions")
;for(var o=0;o<a.length;o++)a[o]|=n.bad[o]}return{cell:e.cell,gw:e.gw,gh:e.gh,w:e.w,h:e.h,bad:a}}(r);console.write("Searching for the best crop ... "),
processEvents();var w=function(t,a){a=e(a);for(var r=t.gw,n=t.gh,o=t.cell,i=r*n,s=new Uint8Array(i),c=0;c<i;c++)s[c]=t.bad[c]?0:1;var f=l(s,r,n,0)
;if(0===f.area)throw new Error("No usable area common to all images");var d=f.axis,u={x0:d.x0*o,y0:d.y0*o,x1:Math.min(t.w,d.x1*o),y1:Math.min(t.h,d.y1*o),
angleDeg:0,rotated:!1};if(u.width=u.x1-u.x0,u.height=u.y1-u.y0,u.cx=(u.x0+u.x1)/2,u.cy=(u.y0+u.y1)/2,u.axisAreaFrac=u.areaFrac=u.width*u.height/(t.w*t.h),
!a.allowRotation)return u;for(var g=new Uint8Array(i),w=0;w<n;w++)for(var m=0;m<r;m++){for(var p=s[w*r+m],v=-1;v<=1&&p;v++)for(var y=-1;y<=1&&p;y++){
var x=m+y,M=w+v;(x<0||M<0||x>=r||M>=n||!s[M*r+x])&&(p=0)}g[w*r+m]=p}var b=Math.PI/180,S=null;function P(t){if(!(Math.abs(t)<1e-9)){var e=l(g,r,n,t*b)
;(!S||e.area>S.area)&&(S=e)}}for(var C=Math.max(1,Math.round(Math.max(r,n)/250)),A=h(g,r,n,C),k=[],B=-45;B<45;B+=.5)k.push({deg:B,area:l(A.g,A.w,A.h,B*b).area})
;k.sort(function(t,e){return e.area-t.area});var _=[];for(c=0;c<k.length&&_.length<3;c++){for(var z=!1,F=0;F<_.length;F++)Math.abs(_[F]-k[c].deg)<2&&(z=!0)
;z||_.push(k[c].deg)}for(c=0;c<_.length;c++)for(B=_[c]-.75;B<=_[c]+.75+1e-9;B+=.05)P(Math.round(1e3*B)/1e3);if(!S)return u;var T=S.angle/b
;for(B=T-.05;B<=T+.05+1e-9;B+=.01)P(Math.round(1e3*B)/1e3);var R=S.w*o,I=S.h*o,D=R*I/(t.w*t.h);return D>=u.axisAreaFrac*(1+a.minGainPct/100)?u={cx:S.cx*o,
cy:S.cy*o,width:R,height:I,angleDeg:S.angle/b,rotated:!0,areaFrac:D,axisAreaFrac:u.axisAreaFrac}:(u.bestRotatedFrac=D,u.bestRotatedDeg=S.angle/b),u}(g,a)
;console.writeln("done");var y=function(t,e){for(var a=e.rotated?[1,-1]:[1],r=0;r<a.length;r++){var n=v(t);n.interpolation=Interpolation_Bilinear,
p(n,e,a[r],[1]);var o=n.maximum()<.5&&n.width===Math.floor(e.width)&&n.height===Math.floor(e.height);if(n.free(),o)return a[r]}return 0}(g,w)
;if(0===y)throw new Error("Internal check failed: the computed crop would include bad pixels. Nothing was changed.");w.sign=y;var x=r[0]
;for(s=1;s<r.length;s++)r[s].goodFrac<x.goodFrac&&(x=r[s]);return{list:r,comb:g,plan:w,worst:x}}(t),this.analysis.ids=t.map(function(t){return t.id}).join("|")
;var b=(i=(o=this.analysis).plan,s=format("%d x %d px",Math.floor(i.width),Math.floor(i.height)),
i.rotated?s+=format(", frame tilted %.2f\xb0 %s",Math.abs(i.angleDeg),i.angleDeg>0?"clockwise":"counter-clockwise"):s+=", no rotation",
s+=format(", keeps %.1f%% of the frame",100*i.areaFrac),
i.rotated?s+=format(" (axis-aligned: %.1f%%)",100*i.axisAreaFrac):void 0!==i.bestRotatedFrac&&g.allowRotation&&(s+=format(" (rotation would give only %.1f%%)",100*i.bestRotatedFrac)),
s+"\nMost limiting image: "+o.worst.id+format(" (%.1f%% usable)",100*o.worst.goodFrac));console.noteln(b),
console.writeln(format("Analysis time %.1f s",(Date.now()-M)/1e3)),this.resultLabel.text=b;var k=function(t,e){
for(var a=t.comb,n=a.w,o=a.h,i=a.cell,s=e[0],l=0;l<e.length;l++)e[l].id===t.worst.id&&(s=e[l])
;for(var h=Math.max(1,Math.ceil(Math.max(n,o)/1400)),c=Math.floor(n/h),f=Math.floor(o/h),d=c*f,u=A(s.image),g=u.length,w=new Float32Array(d),m=0;m<f;m++)for(var p=0;p<c;p++){
for(var v=0,y=0;y<h;y++)for(var x=(m*h+y)*n+p*h,M=0;M<h;M++)for(var b=0;b<g;b++)v+=u[b][x+M];w[m*c+p]=v/(h*h*g)}u=null;var S=[]
;for(l=0;l<d;l+=7)w[l]>0&&S.push(w[l]);var P=r(S),C=1.4826*r(S.map(function(t){return Math.abs(t-P)})),k=Math.max(0,P-2.8*C),B=Math.max(1e-6,1-k)
;function _(t,e){return e<=0?0:e>=1?1:(t-1)*e/((2*t-1)*e-t)}var z=_(.25,(P-k)/B),F=new Float32Array(d),T=new Float32Array(d),R=new Float32Array(d)
;for(m=0;m<f;m++){var I=Math.floor((m*h+h/2)/i)*a.gw;for(p=0;p<c;p++){var D=_(z,(w[l=m*c+p]-k)/B);a.bad[I+Math.floor((p*h+h/2)/i)]?(F[l]=.35+.5*D,T[l]=.4*D,
R[l]=.4*D):F[l]=T[l]=R[l]=D}}var L=new Image(c,f,3,ColorSpace_RGB);L.setSamples(F,new Rect(0,0,c,f),0),L.setSamples(T,new Rect(0,0,c,f),1),
L.setSamples(R,new Rect(0,0,c,f),2);var U=L.render();return L.free(),{bitmap:U,scale:h}}(this.analysis,t);return k.corners=function(t){
var e=t.angleDeg*Math.PI/180,a=Math.cos(e),r=Math.sin(e),n=t.width/2,o=t.height/2;return[[-n,-o],[n,-o],[n,o],[-n,o]].map(function(e){return{
x:t.cx+e[0]*a-e[1]*r,y:t.cy+e[0]*r+e[1]*a}})}(this.analysis.plan),this.preview.setData(k),!0}catch(t){return this.analysis=null,
console.criticalln(t.toString()),this.resultLabel.text="Error: "+t.toString(),new MessageBox(t.toString(),f,StdIcon_Error,StdButton_Ok).execute(),!1}finally{
console.abortEnabled=!1,this.enabled=!0}},_.prototype.apply=function(){var t=this.selectedViews(),e=t.map(function(t){return t.id}).join("|")
;if(this.analysis&&this.analysis.ids===e||this.analyze()){this.enabled=!1;try{!function(t,e){for(var a=e.plan,r=0;r<t.length;r++){var n=t[r],o=n.window
;console.writeln("Cropping "+n.id),processEvents();for(var i=n.image.numberOfChannels,s=[],l=0;l<i;l++)s.push(0);var h=o.hasAstrometricSolution
;n.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{n.image.interpolation=Interpolation_Lanczos3,p(n.image,a,a.sign,s)
;var c=o.keywords
;c.push(new FITSKeyword("HISTORY","",format("SmartCrop %s: %dx%d crop, angle %.3f deg",d,Math.floor(a.width),Math.floor(a.height),a.rotated?a.angleDeg:0))),
o.keywords=c,h&&o.clearAstrometricSolution()}finally{n.endProcess()}
h&&console.warningln("   ** astrometric solution removed (geometry changed) - re-solve the image if needed")}}(t,this.analysis),
console.noteln("<end><cbr>"+f+": "+t.length+" image(s) cropped."),w(),this.ok()}catch(t){console.criticalln(t.toString()),
new MessageBox(t.toString(),f,StdIcon_Error,StdButton_Ok).execute(),this.enabled=!0}}},console.hide(),0!==ImageWindow.openWindows.length?(function(){
function t(t,e,a){var r=Settings.read(u+"/"+t,e);return Settings.lastReadOK?r:a}g.noiseTolPct=t("noiseTolPct",DataType_Double,g.noiseTolPct),
g.scanPx=t("scanPx",DataType_Int32,g.scanPx),g.extraMarginPx=t("extraMarginPx",DataType_Int32,g.extraMarginPx),
g.allowRotation=t("allowRotation",DataType_Boolean,g.allowRotation),g.minGainPct=t("minGainPct",DataType_Double,g.minGainPct)}(),(new _).execute(),
w()):new MessageBox("Open the registered master frames first.",f,StdIcon_Information,StdButton_Ok).execute()}();
