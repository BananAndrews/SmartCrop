// SmartCrop 1.0.4 for PixInsight - Copyright (c) 2026 BananAndrews. All rights reserved.
// Free to use. Modification, reverse engineering and redistribution of modified versions are not permitted.
#feature-id    SmartCrop : Utilities > SmartCrop
#feature-info  Synchronized automatic crop of registered master frames.<br/>\
   Detects black borders and noisy stacking edges on every selected image, \
   finds the largest (optionally rotated) rectangle with good data on all of \
   them and crops all images identically.
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/Interpolation.jsh>
!function(){var t={zeroLevel:0,noiseTol:.3,darkTolSigma:0,scanPx:300,voteRadius:5,extraMarginPx:0,allowRotation:!0,maxAngleDeg:10,minGainPct:2};function e(e){
var a={};for(var r in t)a[r]=t[r];if(e)for(var n in e)a[n]=e[n];return a}function a(t,e){if(void 0===e&&(e=t.length),0===e)return NaN
;var a=Array.prototype.slice.call(t,0,e).sort(function(t,e){return t-e});return 1&e?a[e>>1]:.5*(a[(e>>1)-1]+a[e>>1])}function r(t,r,o,i){i=e(i)
;for(var s=function(t,e){return Math.max(2,Math.round(Math.max(t,e)/1e3))
}(r,o),l=Math.ceil(r/s),h=Math.ceil(o/s),c=l*h,d=t.length,u=new Uint8Array(c),f=new Float32Array(c),g=new Float32Array(c),w=new Float32Array(r),p=new Uint8Array(r),m=new Float64Array(l),v=new Float64Array(l),x=new Int32Array(l),y=new Int32Array(l),b=0;b<h;b++){
for(var M=0;M<l;M++)m[M]=0,v[M]=0,x[M]=0,y[M]=0;for(var P=Math.min(o,(b+1)*s),B=b*s;B<P;B++){for(var S=B*r,A=0;A<r;A++){for(var C=0,T=0,k=0;k<d;k++){
var D=t[k][S+A];D>i.zeroLevel||(T=1),C+=D}w[A]=C/d,p[A]=T}for(M=0;M<l;M++){var _=M*s,z=Math.min(r,_+s),R=b*l+M;for(A=_;A<z;A++)p[A]&&(u[R]=1),m[M]+=w[A],x[M]++,
A+1<z&&(v[M]+=Math.abs(w[A+1]-w[A]),y[M]++)}}for(M=0;M<l;M++)f[R=b*l+M]=m[M]/Math.max(1,x[M]),g[R]=v[M]/Math.max(1,y[M])}
var F=new Uint8Array(c),I=new Int32Array(c),L=0,E=0;function W(t){u[t]&&!F[t]&&(F[t]=1,I[E++]=t)}for(M=0;M<l;M++)W(M),W((h-1)*l+M);for(b=0;b<h;b++)W(b*l),
W(b*l+l-1);for(;L<E;)for(var G=((H=I[L++])-(gt=H%l))/l,N=-1;N<=1;N++)for(var O=-1;O<=1;O++){var V=G+N;(wt=gt+O)>=0&&V>=0&&wt<l&&V<h&&W(V*l+wt)}
for(var U=new Float32Array(c),H=0;H<c;H++)U[H]=F[H]?0:1e9;function j(t,e){return t<0||e<0||t>=l||e>=h?0:U[e*l+t]}
for(B=0;B<h;B++)for(A=0;A<l;A++)0!==U[H=B*l+A]&&(U[H]=Math.min(U[H],j(A-1,B)+3,j(A,B-1)+3,j(A-1,B-1)+4,j(A+1,B-1)+4))
;for(B=h-1;B>=0;B--)for(A=l-1;A>=0;A--)0!==U[H=B*l+A]&&(U[H]=Math.min(U[H],j(A+1,B)+3,j(A,B+1)+3,j(A+1,B+1)+4,j(A-1,B+1)+4));var Y=new Int32Array(c)
;for(H=0;H<c;H++)Y[H]=F[H]?0:Math.max(1,Math.round(U[H]/3))
;var K=Math.max(4,Math.round(i.scanPx/s)),Q=n(f,Y,l,h,K),Z=n(g,Y,l,h,K),q=a(Array.prototype.filter.call(Z,function(t,e){return!F[e]})),J=new Uint8Array(c)
;for(H=0;H<c;H++)if(!(F[H]||Y[H]>K+i.voteRadius)){var X=Math.max(Z[H],.25*q),$=X/1.128
;(g[H]>(1+i.noiseTol)*X||i.darkTolSigma>0&&f[H]<Q[H]-i.darkTolSigma*$)&&(J[H]=1)}
var tt=i.voteRadius,et=l+1,at=new Int32Array(et*(h+1)),rt=new Int32Array(et*(h+1));for(B=0;B<h;B++){var nt=0,ot=0;for(A=0;A<l;A++){var it=(B+1)*et+A+1
;nt+=J[H=B*l+A],ot+=F[H]?0:1,at[it]=at[it-et]+nt,rt[it]=rt[it-et]+ot}}var st=new Uint8Array(c);for(B=0;B<h;B++)for(A=0;A<l;A++)if(!(F[H=B*l+A]||Y[H]>K)){
var lt=Math.max(0,A-tt),ht=Math.min(l,A+tt+1),ct=Math.max(0,B-tt),dt=Math.min(h,B+tt+1)
;2*(at[dt*et+ht]-at[ct*et+ht]-at[dt*et+lt]+at[ct*et+lt])>rt[dt*et+ht]-rt[ct*et+ht]-rt[dt*et+lt]+rt[ct*et+lt]&&(st[H]=1)}var ut=new Uint8Array(c);for(L=E=0,
H=0;H<c;H++)F[H]&&(ut[H]=1,I[E++]=H);function ft(t){st[t]&&!ut[t]&&(ut[t]=1,I[E++]=t)}for(M=0;M<l;M++)ft(M),ft((h-1)*l+M);for(b=0;b<h;b++)ft(b*l),ft(b*l+l-1)
;for(;L<E;){var gt;for(G=((H=I[L++])-(gt=H%l))/l,N=-1;N<=1;N++)for(O=-1;O<=1;O++){var wt;V=G+N,(wt=gt+O)>=0&&V>=0&&wt<l&&V<h&&ft(V*l+wt)}}
var pt=Math.ceil(i.extraMarginPx/s),mt=0,vt=0,xt=[];for(H=0;H<c;H++)ut[H]&&!F[H]&&vt++,!ut[H]&&pt>0&&Y[H]<=pt&&(ut[H]=1),ut[H]||mt++;var yt=0
;for(H=0;H<c;H++)yt+=F[H];var bt=0;for(H=0;H<c;H++)ut[H]&&!F[H]&&Y[H]>=K&&bt++;return bt>0&&xt.push("edge artifacts reach the "+i.scanPx+" px scan limit"),{
cell:s,gw:l,gh:h,w:r,h:o,bad:ut,goodFrac:mt/c,noDataFrac:yt/c,artifactFrac:vt/c,noiseRef:q,notes:xt}}function n(t,e,r,n,i){
for(var s=Math.max(8,Math.round(Math.max(r,n)/24)),l=[],h=0;h<n;h+=s)for(var c=0;c<r;c+=s){
for(var d=[],u=h;u<Math.min(n,h+s);u++)for(var f=c;f<Math.min(r,c+s);f++)e[S=u*r+f]>i&&d.push(t[S]);d.length>=s*s/2&&l.push({x:2*(c+s/2)/r-1,y:2*(h+s/2)/n-1,
v:a(d)})}function g(t,e){return[1,t,e,t*t,t*e,e*e]}for(var w=null,p=l,m=0;m<4&&!(p.length<10);m++){
for(var v=[],x=[0,0,0,0,0,0],y=0;y<6;y++)v.push([0,0,0,0,0,0]);p.forEach(function(t){for(var e=g(t.x,t.y),a=0;a<6;a++){x[a]+=e[a]*t.v
;for(var r=0;r<6;r++)v[a][r]+=e[a]*e[r]}}),w=o(v,x);var b=l.map(function(t){for(var e=g(t.x,t.y),a=0,r=0;r<6;r++)a+=w[r]*e[r];return t.v-a
}),M=1.4826*a(b.map(Math.abs))+1e-30;p=l.filter(function(t,e){return Math.abs(b[e])<3*M})}var P=new Float32Array(r*n);if(!w){
for(var B=a(l.length?l.map(function(t){return t.v}):[0]),S=0;S<P.length;S++)P[S]=B;return P}for(u=0;u<n;u++)for(f=0;f<r;f++){
var A=g(2*(f+.5)/r-1,2*(u+.5)/n-1),C=0;for(y=0;y<6;y++)C+=w[y]*A[y];P[u*r+f]=C}return P}function o(t,e){for(var a=e.length,r=t.map(function(t,a){
return t.concat([e[a]])}),n=0;n<a;n++){for(var o=n,i=n+1;i<a;i++)Math.abs(r[i][n])>Math.abs(r[o][n])&&(o=i);var s=r[n];if(r[n]=r[o],r[o]=s,
!(Math.abs(r[n][n])<1e-300))for(i=n+1;i<a;i++)for(var l=r[i][n]/r[n][n],h=n;h<=a;h++)r[i][h]-=l*r[n][h]}var c=[];for(i=0;i<a;i++)c.push(0);for(i=a-1;i>=0;i--){
var d=r[i][a];for(h=i+1;h<a;h++)d-=r[i][h]*c[h];c[i]=Math.abs(r[i][i])<1e-300?0:d/r[i][i]}return c}function i(t,e,a){
for(var r=new Int32Array(e),n=new Int32Array(e+1),o={area:0,x0:0,y0:0,x1:0,y1:0},i=0;i<a;i++){for(var s=i*e,l=0;l<e;l++)r[l]=t[s+l]?r[l]+1:0;var h=0
;for(l=0;l<=e;l++){for(var c=l<e?r[l]:0;h>0&&r[n[h-1]]>=c;){var d=r[n[--h]],u=h>0?n[h-1]+1:0,f=d*(l-u);f>o.area&&(o={area:f,x0:u,y0:i-d+1,x1:l,y1:i+1})}n[h++]=l
}}return o}function s(t,e,a,r){if(0===r)return{area:(v=i(t,e,a)).area,cx:(v.x0+v.x1)/2,cy:(v.y0+v.y1)/2,w:v.x1-v.x0,h:v.y1-v.y0,angle:0,axis:v}
;for(var n=Math.cos(r),o=Math.sin(r),s=Math.ceil(e*Math.abs(n)+a*Math.abs(o)),l=Math.ceil(e*Math.abs(o)+a*Math.abs(n)),h=new Uint8Array(s*l),c=e/2,d=a/2,u=0;u<l;u++)for(var f=u+.5-l/2,g=0;g<s;g++){
var w=g+.5-s/2,p=Math.floor(c+w*n-f*o),m=Math.floor(d+w*o+f*n);p>=0&&m>=0&&p<e&&m<a&&(h[u*s+g]=t[m*e+p])}var v;return w=((v=i(h,s,l)).x0+v.x1)/2-s/2,
f=(v.y0+v.y1)/2-l/2,{area:v.area,cx:c+w*n-f*o,cy:d+w*o+f*n,w:v.x1-v.x0,h:v.y1-v.y0,angle:r}}var l="SmartCrop",h="1.0.4",c="SmartCrop",d={noiseTolPct:30,
scanPx:300,extraMarginPx:0,allowRotation:!0,maxAngleDeg:10,minGainPct:2,createPreview:!1};function u(){
Settings.write(c+"/noiseTolPct",DataType_Double,d.noiseTolPct),Settings.write(c+"/scanPx",DataType_Int32,d.scanPx),
Settings.write(c+"/extraMarginPx",DataType_Int32,d.extraMarginPx),Settings.write(c+"/allowRotation",DataType_Boolean,d.allowRotation),
Settings.write(c+"/maxAngleDeg",DataType_Double,d.maxAngleDeg),Settings.write(c+"/minGainPct",DataType_Double,d.minGainPct),
Settings.write(c+"/createPreview",DataType_Boolean,d.createPreview)}function f(t,e,a,r){if(e.rotated){
var n=e.angleDeg*Math.PI/180,o=Math.abs(Math.cos(n)),i=Math.abs(Math.sin(n)),s=Math.floor(e.width),l=Math.floor(e.height),h=Math.max(s/2,s/2*o+l/2*i),c=Math.max(l/2,s/2*i+l/2*o),d=Math.floor(e.cx-h-8),u=Math.floor(e.cy-c-8),f=Math.ceil(e.cx+h+8),g=Math.ceil(e.cy+c+8)
;t.cropTo(d,u,f,g,r);var w=e.cx-d,p=e.cy-u;t.rotate(a*n,w,p,r);var m=Math.round(w-s/2),v=Math.round(p-l/2);t.cropTo(m,v,m+s,v+l,r)
}else t.cropTo(e.x0,e.y0,e.x1,e.y1,r)}function g(t){
for(var e=t.w,a=t.h,r=t.cell,n=new Float32Array(e*a),o=0;o<a;o++)for(var i=Math.floor(o/r)*t.gw,s=o*e,l=0;l<e;l++)n[s+l]=t.bad[i+Math.floor(l/r)]
;var h=new Image(e,a,1,ColorSpace_Gray);return h.setSamples(n,new Rect(0,0,e,a),0),h}function w(t){
for(var e=[],a=0;a<t.numberOfChannels;a++)e.push(t.toFloat32Array(new Rect(0,0,t.width,t.height),a));return e}function p(t){
for(var e=t.keywords,a=0;a<e.length;a++)if("HISTORY"===e[a].name&&(e[a].comment+" "+e[a].value).indexOf("SmartCrop")>=0)return!0;return!1}function m(){
this.__base__=Dialog,this.__base__();var t=this;this.analysis=null;var e=this.font.width("Max rotation angle (\xb0):")+8;this.helpLabel=new Label(this),
this.helpLabel.frameStyle=FrameStyle_Box,this.helpLabel.margin=6,this.helpLabel.wordWrapping=!0,this.helpLabel.useRichText=!0,
this.helpLabel.text="<b>"+l+" v"+h+"</b> &mdash; tick the registered masters to crop. The script finds black borders and noisy stacking edges on each of them, builds the largest rectangle that is clean on <i>all</i> of them (rotated if that keeps more of the field) and crops every ticked image identically. Each crop can be undone (Ctrl+Z).",
this.tree=new TreeBox(this),this.tree.numberOfColumns=3,this.tree.headerVisible=!0,this.tree.setHeaderText(0,"Image"),this.tree.setHeaderText(1,"Size"),
this.tree.setHeaderText(2,"Channels"),this.tree.rootDecoration=!1,this.tree.alternateRowColor=!0,this.tree.setScaledMinSize(480,200)
;for(var a=ImageWindow.openWindows,r=0;r<a.length;r++)if(!a[r].isNull&&(a[r].visible||a[r].iconic)){var n=a[r].mainView
;if(!n.isNull&&0!==n.id.indexOf("SmartCrop_preview")){var o=new TreeBoxNode(this.tree);o.checkable=!0,o.checked=!0,o.setText(0,n.id),
o.setText(1,n.image.width+" x "+n.image.height),o.setText(2,n.image.isColor?"RGB":"Gray"),o.viewId=n.id}}
for(var i=0;i<3;i++)this.tree.adjustColumnWidthToContents(i);function s(a,r,n,o,i,s,l){var h=new NumericControl(t);return h.label.text=a,h.label.minWidth=e,
h.setRange(r,n),h.slider.setRange(0,Math.round((n-r)*Math.pow(10,Math.min(o,1)))),h.slider.scaledMinWidth=200,h.setPrecision(o),h.setValue(i),h.toolTip=s,
h.onValueUpdated=function(e){l(e),t.invalidate()},h}this.tree.onNodeUpdated=function(){t.invalidate()},this.allButton=new PushButton(this),
this.allButton.text="Select all",this.allButton.onClick=function(){t.setAll(!0)},this.noneButton=new PushButton(this),this.noneButton.text="Select none",
this.noneButton.onClick=function(){t.setAll(!1)},this.listButtons=new HorizontalSizer,this.listButtons.spacing=6,this.listButtons.add(this.allButton),
this.listButtons.add(this.noneButton),
this.listButtons.addStretch(),this.noiseCtl=s("Edge noise tolerance (%):",5,200,0,d.noiseTolPct,"<p>Edges whose noise exceeds the interior noise by more than this are cut off (areas covered by fewer subframes). Lower = stricter crop.</p>",function(t){
d.noiseTolPct=t
}),this.scanCtl=s("Max edge depth (px):",20,1e3,0,d.scanPx,"<p>Noisy edges are searched for no deeper than this from the data border.</p>",function(t){
d.scanPx=Math.round(t)}),this.marginCtl=s("Extra margin (px):",0,200,0,d.extraMarginPx,"<p>Additional safety margin cut from the usable area.</p>",function(t){
d.extraMarginPx=Math.round(t)}),this.rotCheck=new CheckBox(this),this.rotCheck.text="Allow rotated crop",this.rotCheck.checked=d.allowRotation,
this.rotCheck.toolTip="<p>Rotate the crop rectangle (and the images) when this keeps noticeably more of the field.</p>",this.rotCheck.onCheck=function(e){
d.allowRotation=e,t.angleCtl.enabled=t.gainCtl.enabled=e,t.invalidate()
},this.angleCtl=s("Max rotation angle (\xb0):",.5,45,1,d.maxAngleDeg,"<p>Largest rotation tried for the crop rectangle.</p>",function(t){d.maxAngleDeg=t}),
this.gainCtl=s("Min area gain (%):",0,20,1,d.minGainPct,"<p>Rotate only if the rotated crop is at least this much larger than the best axis-aligned one (rotation resamples the images).</p>",function(t){
d.minGainPct=t}),this.angleCtl.enabled=this.gainCtl.enabled=d.allowRotation,this.previewCheck=new CheckBox(this),
this.previewCheck.text="Show analysis preview image",this.previewCheck.checked=d.createPreview,
this.previewCheck.toolTip="<p>After analysis, open a stretched copy of the most limiting image: unusable area tinted red, crop outline in yellow. It is closed automatically when you press Crop.</p>",
this.previewCheck.onCheck=function(t){d.createPreview=t},this.paramBox=new GroupBox(this),this.paramBox.title="Parameters",
this.paramBox.sizer=new VerticalSizer,this.paramBox.sizer.margin=6,this.paramBox.sizer.spacing=4,this.paramBox.sizer.add(this.noiseCtl),
this.paramBox.sizer.add(this.scanCtl),this.paramBox.sizer.add(this.marginCtl),this.paramBox.sizer.add(this.rotCheck),this.paramBox.sizer.add(this.angleCtl),
this.paramBox.sizer.add(this.gainCtl),this.paramBox.sizer.add(this.previewCheck),this.resultLabel=new Label(this),this.resultLabel.frameStyle=FrameStyle_Sunken,
this.resultLabel.margin=6,this.resultLabel.wordWrapping=!0,this.resultLabel.text="Press Analyze to compute the crop.",this.resultLabel.setScaledMinHeight(48),
this.analyzeButton=new PushButton(this),this.analyzeButton.text="Analyze",this.analyzeButton.icon=this.scaledResource(":/icons/find.png"),
this.analyzeButton.onClick=function(){t.analyze()},this.applyButton=new PushButton(this),this.applyButton.text="Crop",
this.applyButton.icon=this.scaledResource(":/icons/ok.png"),this.applyButton.toolTip="<p>Crop all ticked images (analyzes first if needed).</p>",
this.applyButton.onClick=function(){t.apply()},this.closeButton=new PushButton(this),this.closeButton.text="Close",
this.closeButton.icon=this.scaledResource(":/icons/close.png"),this.closeButton.onClick=function(){t.cancel()},this.heartLabel=new Label(this),
this.heartLabel.useRichText=!0,this.heartLabel.text='<span style="color:#e0245e; font-size:15pt;">&#9829;</span>',
this.heartLabel.toolTip="<p>Like SmartCrop? Support its development with a donation (PayPal).</p>",this.heartLabel.cursor=new Cursor(StdCursor_PointingHand),
this.heartLabel.onMousePress=function(){
Dialog.openBrowser("https://www.paypal.com/donate/?business=contact%40bluebelleweddings.com&no_recurring=0&item_name=SmartCrop")},
this.buttons=new HorizontalSizer,this.buttons.spacing=6,this.buttons.add(this.heartLabel),this.buttons.addStretch(),this.buttons.add(this.analyzeButton),
this.buttons.add(this.applyButton),this.buttons.add(this.closeButton),this.sizer=new VerticalSizer,this.sizer.margin=8,this.sizer.spacing=6,
this.sizer.add(this.helpLabel),this.sizer.add(this.tree,100),this.sizer.add(this.listButtons),this.sizer.add(this.paramBox),this.sizer.add(this.resultLabel),
this.sizer.add(this.buttons),this.windowTitle=l+" v"+h,this.adjustToContents(),this.setScaledMinWidth(560)}m.prototype=new Dialog,
m.prototype.closePreview=function(){this.previewWindow&&!this.previewWindow.isNull&&this.previewWindow.forceClose(),this.previewWindow=null},
m.prototype.setAll=function(t){for(var e=0;e<this.tree.numberOfChildren;e++)this.tree.child(e).checked=t;this.invalidate()},m.prototype.invalidate=function(){
this.analysis&&(this.resultLabel.text="Parameters or selection changed - press Analyze again."),this.analysis=null},m.prototype.selectedViews=function(){
for(var t=[],e=0;e<this.tree.numberOfChildren;e++){var a=this.tree.child(e);if(a.checked){var r=View.viewById(a.viewId);r&&!r.isNull&&t.push(r)}}return t},
m.prototype.analyze=function(){var t=this.selectedViews()
;if(0===t.length)return new MessageBox("Tick at least one image.",l,StdIcon_Warning,StdButton_Ok).execute(),!1
;for(var n,o,i,c=[],u=0;u<t.length;u++)p(t[u].window)&&c.push(t[u].id)
;if(c.length>0&&new MessageBox("Already cropped by SmartCrop:\n   "+c.join("\n   ")+"\n\nAnalyze again anyway? A second pass may trim the edges a little more.",l,StdIcon_Question,StdButton_Yes,StdButton_No).execute()!==StdButton_Yes)return!1
;this.enabled=!1,console.show(),console.abortEnabled=!0;try{console.noteln("<end><cbr><br>"+l+" v"+h+": "+t.length+" image(s)");var m=Date.now()
;this.analysis=function(t){for(var a={noiseTol:d.noiseTolPct/100,scanPx:d.scanPx,extraMarginPx:d.extraMarginPx,allowRotation:d.allowRotation,
maxAngleDeg:d.maxAngleDeg,minGainPct:d.minGainPct},n=[],o=t[0].image.width,i=t[0].image.height,l=0;l<t.length;l++){var h=t[l].image
;if(h.width!==o||h.height!==i)throw new Error(t[l].id+" is "+h.width+"x"+h.height+", but "+t[0].id+" is "+o+"x"+i+". All images must be registered to the same frame.")
}for(l=0;l<t.length;l++){var c=Date.now();console.write("<end><cbr>Analyzing "+t[l].id+" ... "),processEvents();var u=r(w(t[l].image),o,i,a);u.id=t[l].id,
console.writeln(format("good %.1f%% (no data %.1f%%, noisy edges %.1f%%)  %.1f s",100*u.goodFrac,100*u.noDataFrac,100*u.artifactFrac,(Date.now()-c)/1e3))
;for(var p=0;p<u.notes.length;p++)console.warningln("   ** "+u.notes[p]);n.push(u),processEvents(),gc()}var m=function(t){
for(var e=t[0],a=new Uint8Array(e.bad.length),r=0;r<t.length;r++){var n=t[r];if(n.w!==e.w||n.h!==e.h)throw new Error("Images have different dimensions")
;for(var o=0;o<a.length;o++)a[o]|=n.bad[o]}return{cell:e.cell,gw:e.gw,gh:e.gh,w:e.w,h:e.h,bad:a}}(n);console.write("Searching for the best crop ... "),
processEvents();var v=function(t,a){a=e(a);for(var r=t.gw,n=t.gh,o=t.cell,i=r*n,l=new Uint8Array(i),h=0;h<i;h++)l[h]=t.bad[h]?0:1;var c=s(l,r,n,0)
;if(0===c.area)throw new Error("No usable area common to all images");var d=c.axis,u={x0:d.x0*o,y0:d.y0*o,x1:Math.min(t.w,d.x1*o),y1:Math.min(t.h,d.y1*o),
angleDeg:0,rotated:!1};if(u.width=u.x1-u.x0,u.height=u.y1-u.y0,u.cx=(u.x0+u.x1)/2,u.cy=(u.y0+u.y1)/2,u.axisAreaFrac=u.areaFrac=u.width*u.height/(t.w*t.h),
!a.allowRotation||a.maxAngleDeg<=0)return u;for(var f=new Uint8Array(i),g=0;g<n;g++)for(var w=0;w<r;w++){
for(var p=l[g*r+w],m=-1;m<=1&&p;m++)for(var v=-1;v<=1&&p;v++){var x=w+v,y=g+m;(x<0||y<0||x>=r||y>=n||!l[y*r+x])&&(p=0)}f[g*r+w]=p}var b=Math.PI/180,M=null
;function P(t){if(0!==t){var e=s(f,r,n,t*b);(!M||e.area>M.area)&&(M=e)}}for(var B=.25,S=-a.maxAngleDeg;S<=a.maxAngleDeg+1e-9;S+=B)P(Math.round(1e3*S)/1e3)
;if(!M)return u;var A=M.angle/b;for(S=A-B;S<=A+B+1e-9;S+=.02)P(Math.round(1e3*S)/1e3);var C=M.w*o,T=M.h*o,k=C*T/(t.w*t.h)
;return k>=u.axisAreaFrac*(1+a.minGainPct/100)?u={cx:M.cx*o,cy:M.cy*o,width:C,height:T,angleDeg:M.angle/b,rotated:!0,areaFrac:k,axisAreaFrac:u.axisAreaFrac
}:(u.bestRotatedFrac=k,u.bestRotatedDeg=M.angle/b),u}(m,a);console.writeln("done");var x=function(t,e){for(var a=e.rotated?[1,-1]:[1],r=0;r<a.length;r++){
var n=g(t);n.interpolation=Interpolation_Bilinear,f(n,e,a[r],[1]);var o=n.maximum()<.5&&n.width===Math.floor(e.width)&&n.height===Math.floor(e.height)
;if(n.free(),o)return a[r]}return 0}(m,v);if(0===x)throw new Error("Internal check failed: the computed crop would include bad pixels. Nothing was changed.")
;v.sign=x;var y=n[0];for(l=1;l<n.length;l++)n[l].goodFrac<y.goodFrac&&(y=n[l]);return{list:n,comb:m,plan:v,worst:y}}(t),this.analysis.ids=t.map(function(t){
return t.id}).join("|");var v=(o=(n=this.analysis).plan,i=format("%d x %d px",Math.floor(o.width),Math.floor(o.height)),
o.rotated?i+=format(", frame tilted %.2f\xb0 %s",Math.abs(o.angleDeg),o.angleDeg>0?"clockwise":"counter-clockwise"):i+=", no rotation",
i+=format(", keeps %.1f%% of the frame",100*o.areaFrac),
o.rotated?i+=format(" (axis-aligned: %.1f%%)",100*o.axisAreaFrac):void 0!==o.bestRotatedFrac&&d.allowRotation&&(i+=format(" (rotation would give only %.1f%%)",100*o.bestRotatedFrac)),
i+"\nMost limiting image: "+n.worst.id+format(" (%.1f%% usable)",100*n.worst.goodFrac));return console.noteln(v),
console.writeln(format("Analysis time %.1f s",(Date.now()-m)/1e3)),this.resultLabel.text=v,this.closePreview(),
d.createPreview&&(this.previewWindow=function(t,e){for(var r=t.comb,n=t.plan,o=r.w,i=r.h,s=r.cell,l=o*i,h=e[0],c=0;c<e.length;c++)e[c].id===t.worst.id&&(h=e[c])
;var d=w(h.image),u=d.length,f=new Float32Array(l);for(c=0;c<l;c++){for(var g=0,p=0;p<u;p++)g+=d[p][c];f[c]=g/u}d=null;var m=[]
;for(c=0;c<l;c+=97)f[c]>0&&m.push(f[c]);var v=a(m),x=1.4826*a(m.map(function(t){return Math.abs(t-v)})),y=Math.max(0,v-2.8*x),b=Math.max(1e-6,1-y)
;function M(t,e){return e<=0?0:e>=1?1:(t-1)*e/((2*t-1)*e-t)}
for(var P=M(.25,(v-y)/b),B=new Float32Array(l),S=new Float32Array(l),A=new Float32Array(l),C=0;C<i;C++)for(var T=Math.floor(C/s)*r.gw,k=0;k<o;k++){
var D=M(P,(f[c=C*o+k]-y)/b);r.bad[T+Math.floor(k/s)]?(B[c]=.35+.5*D,S[c]=.4*D,A[c]=.4*D):B[c]=S[c]=A[c]=D}f=null
;for(var _=n.angleDeg*Math.PI/180,z=Math.cos(_),R=Math.sin(_),F=n.width,I=n.height,L=2*(F+I),E=Math.max(2,Math.round(Math.max(o,i)/700)),W=0;W<=1;W+=1/L){
var G=[[(W-.5)*F,-I/2],[(W-.5)*F,I/2],[-F/2,(W-.5)*I],[F/2,(W-.5)*I]];for(p=0;p<4;p++)for(var N=G[p][0],O=(D=G[p][1],
-E);O<=E;O++)k=Math.round(n.cx+N*z-D*R+(p>=2?O:0)),C=Math.round(n.cy+N*R+D*z+(p<2?O:0)),k>=0&&C>=0&&k<o&&C<i&&(B[c=C*o+k]=1,S[c]=.85,A[c]=0)}
var V=ImageWindow.windowById("SmartCrop_preview");V&&!V.isNull&&V.forceClose();var U=new ImageWindow(o,i,3,32,!0,!0,"SmartCrop_preview")
;return U.mainView.beginProcess(UndoFlag_NoSwapFile),U.mainView.image.setSamples(B,new Rect(0,0,o,i),0),U.mainView.image.setSamples(S,new Rect(0,0,o,i),1),
U.mainView.image.setSamples(A,new Rect(0,0,o,i),2),U.mainView.endProcess(),U.show(),U.zoomToFit(),U}(this.analysis,t)),!0}catch(t){return this.analysis=null,
console.criticalln(t.toString()),this.resultLabel.text="Error: "+t.toString(),new MessageBox(t.toString(),l,StdIcon_Error,StdButton_Ok).execute(),!1}finally{
console.abortEnabled=!1,this.enabled=!0}},m.prototype.apply=function(){var t=this.selectedViews(),e=t.map(function(t){return t.id}).join("|")
;if(this.analysis&&this.analysis.ids===e||this.analyze()){this.enabled=!1;try{!function(t,e){for(var a=e.plan,r=0;r<t.length;r++){var n=t[r],o=n.window
;console.writeln("Cropping "+n.id),processEvents();for(var i=n.image.numberOfChannels,s=[],l=0;l<i;l++)s.push(0);var c=o.hasAstrometricSolution
;n.beginProcess(UndoFlag_DefaultMode);try{n.image.interpolation=Interpolation_Lanczos3,f(n.image,a,a.sign,s)}finally{n.endProcess()}var d=o.keywords
;d.push(new FITSKeyword("HISTORY","",format("SmartCrop %s: %dx%d crop, angle %.3f deg",h,Math.floor(a.width),Math.floor(a.height),a.rotated?a.angleDeg:0))),
o.keywords=d,c&&(o.clearAstrometricSolution(),console.warningln("   ** astrometric solution removed (geometry changed) - re-solve the image if needed"))}
}(t,this.analysis),console.noteln("<end><cbr>"+l+": "+t.length+" image(s) cropped."),u(),this.closePreview(),this.ok()}catch(t){
console.criticalln(t.toString()),new MessageBox(t.toString(),l,StdIcon_Error,StdButton_Ok).execute(),this.enabled=!0}}},console.hide(),
0!==ImageWindow.openWindows.length?(function(){function t(t,e,a){var r=Settings.read(c+"/"+t,e);return Settings.lastReadOK?r:a}
d.noiseTolPct=t("noiseTolPct",DataType_Double,d.noiseTolPct),d.scanPx=t("scanPx",DataType_Int32,d.scanPx),
d.extraMarginPx=t("extraMarginPx",DataType_Int32,d.extraMarginPx),d.allowRotation=t("allowRotation",DataType_Boolean,d.allowRotation),
d.maxAngleDeg=t("maxAngleDeg",DataType_Double,d.maxAngleDeg),d.minGainPct=t("minGainPct",DataType_Double,d.minGainPct),
d.createPreview=t("createPreview",DataType_Boolean,d.createPreview)}(),(new m).execute(),
u()):new MessageBox("Open the registered master frames first.",l,StdIcon_Information,StdButton_Ok).execute()}();
