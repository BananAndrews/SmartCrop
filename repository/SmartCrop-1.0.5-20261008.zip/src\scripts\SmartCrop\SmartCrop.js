// SmartCrop 1.0.5 for PixInsight - Copyright (c) 2026 BananAndrews. All rights reserved.
// Free to use. Modification, reverse engineering and redistribution of modified versions are not permitted.
#feature-id    SmartCrop : Utilities > SmartCrop
#feature-info  Synchronized automatic crop of registered master frames.<br/>\
   Detects black borders and noisy stacking edges on every selected image, \
   finds the largest (optionally rotated) rectangle with good data on all of \
   them and crops all images identically.
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/Interpolation.jsh>
!function(){var t={zeroLevel:0,noiseTol:.3,darkTolSigma:0,scanPx:300,voteRadius:5,extraMarginPx:0,allowRotation:!0,maxAngleDeg:10,minGainPct:2};function e(e){
var a={};for(var r in t)a[r]=t[r];if(e)for(var n in e)a[n]=e[n];return a}function a(t,e){if(void 0===e&&(e=t.length),0===e)return NaN
;var a=Array.prototype.slice.call(t,0,e).sort(function(t,e){return t-e});return 1&e?a[e>>1]:.5*(a[(e>>1)-1]+a[e>>1])}function r(t,r,o,i){i=e(i)
;for(var s=function(t,e){return Math.max(2,Math.round(Math.max(t,e)/1e3))
}(r,o),l=Math.ceil(r/s),h=Math.ceil(o/s),c=l*h,d=t.length,f=new Uint8Array(c),u=new Float32Array(c),g=new Float32Array(c),p=new Float32Array(r),m=new Uint8Array(r),w=new Float64Array(l),x=new Float64Array(l),v=new Int32Array(l),y=new Int32Array(l),b=0;b<h;b++){
for(var M=0;M<l;M++)w[M]=0,x[M]=0,v[M]=0,y[M]=0;for(var S=Math.min(o,(b+1)*s),B=b*s;B<S;B++){for(var A=B*r,P=0;P<r;P++){for(var z=0,C=0,T=0;T<d;T++){
var D=t[T][A+P];D>i.zeroLevel||(C=1),z+=D}p[P]=z/d,m[P]=C}for(M=0;M<l;M++){var k=M*s,_=Math.min(r,k+s),R=b*l+M;for(P=k;P<_;P++)m[P]&&(f[R]=1),w[M]+=p[P],v[M]++,
P+1<_&&(x[M]+=Math.abs(p[P+1]-p[P]),y[M]++)}}for(M=0;M<l;M++)u[R=b*l+M]=w[M]/Math.max(1,v[M]),g[R]=x[M]/Math.max(1,y[M])}
var F=new Uint8Array(c),I=new Int32Array(c),L=0,E=0;function G(t){f[t]&&!F[t]&&(F[t]=1,I[E++]=t)}for(M=0;M<l;M++)G(M),G((h-1)*l+M);for(b=0;b<h;b++)G(b*l),
G(b*l+l-1);for(;L<E;)for(var U=((H=I[L++])-(gt=H%l))/l,O=-1;O<=1;O++)for(var N=-1;N<=1;N++){var V=U+O;(pt=gt+N)>=0&&V>=0&&pt<l&&V<h&&G(V*l+pt)}
for(var W=new Float32Array(c),H=0;H<c;H++)W[H]=F[H]?0:1e9;function j(t,e){return t<0||e<0||t>=l||e>=h?0:W[e*l+t]}
for(B=0;B<h;B++)for(P=0;P<l;P++)0!==W[H=B*l+P]&&(W[H]=Math.min(W[H],j(P-1,B)+3,j(P,B-1)+3,j(P-1,B-1)+4,j(P+1,B-1)+4))
;for(B=h-1;B>=0;B--)for(P=l-1;P>=0;P--)0!==W[H=B*l+P]&&(W[H]=Math.min(W[H],j(P+1,B)+3,j(P,B+1)+3,j(P+1,B+1)+4,j(P-1,B+1)+4));var Y=new Int32Array(c)
;for(H=0;H<c;H++)Y[H]=F[H]?0:Math.max(1,Math.round(W[H]/3))
;var K=Math.max(4,Math.round(i.scanPx/s)),Q=n(u,Y,l,h,K),Z=n(g,Y,l,h,K),q=a(Array.prototype.filter.call(Z,function(t,e){return!F[e]})),J=new Uint8Array(c)
;for(H=0;H<c;H++)if(!(F[H]||Y[H]>K+i.voteRadius)){var X=Math.max(Z[H],.25*q),$=X/1.128
;(g[H]>(1+i.noiseTol)*X||i.darkTolSigma>0&&u[H]<Q[H]-i.darkTolSigma*$)&&(J[H]=1)}
var tt=i.voteRadius,et=l+1,at=new Int32Array(et*(h+1)),rt=new Int32Array(et*(h+1));for(B=0;B<h;B++){var nt=0,ot=0;for(P=0;P<l;P++){var it=(B+1)*et+P+1
;nt+=J[H=B*l+P],ot+=F[H]?0:1,at[it]=at[it-et]+nt,rt[it]=rt[it-et]+ot}}var st=new Uint8Array(c);for(B=0;B<h;B++)for(P=0;P<l;P++)if(!(F[H=B*l+P]||Y[H]>K)){
var lt=Math.max(0,P-tt),ht=Math.min(l,P+tt+1),ct=Math.max(0,B-tt),dt=Math.min(h,B+tt+1)
;2*(at[dt*et+ht]-at[ct*et+ht]-at[dt*et+lt]+at[ct*et+lt])>rt[dt*et+ht]-rt[ct*et+ht]-rt[dt*et+lt]+rt[ct*et+lt]&&(st[H]=1)}var ft=new Uint8Array(c);for(L=E=0,
H=0;H<c;H++)F[H]&&(ft[H]=1,I[E++]=H);function ut(t){st[t]&&!ft[t]&&(ft[t]=1,I[E++]=t)}for(M=0;M<l;M++)ut(M),ut((h-1)*l+M);for(b=0;b<h;b++)ut(b*l),ut(b*l+l-1)
;for(;L<E;){var gt;for(U=((H=I[L++])-(gt=H%l))/l,O=-1;O<=1;O++)for(N=-1;N<=1;N++){var pt;V=U+O,(pt=gt+N)>=0&&V>=0&&pt<l&&V<h&&ut(V*l+pt)}}
var mt=Math.ceil(i.extraMarginPx/s),wt=0,xt=0,vt=[];for(H=0;H<c;H++)ft[H]&&!F[H]&&xt++,!ft[H]&&mt>0&&Y[H]<=mt&&(ft[H]=1),ft[H]||wt++;var yt=0
;for(H=0;H<c;H++)yt+=F[H];var bt=0;for(H=0;H<c;H++)ft[H]&&!F[H]&&Y[H]>=K&&bt++;return bt>0&&vt.push("edge artifacts reach the "+i.scanPx+" px scan limit"),{
cell:s,gw:l,gh:h,w:r,h:o,bad:ft,goodFrac:wt/c,noDataFrac:yt/c,artifactFrac:xt/c,noiseRef:q,notes:vt}}function n(t,e,r,n,i){
for(var s=Math.max(8,Math.round(Math.max(r,n)/24)),l=[],h=0;h<n;h+=s)for(var c=0;c<r;c+=s){
for(var d=[],f=h;f<Math.min(n,h+s);f++)for(var u=c;u<Math.min(r,c+s);u++)e[A=f*r+u]>i&&d.push(t[A]);d.length>=s*s/2&&l.push({x:2*(c+s/2)/r-1,y:2*(h+s/2)/n-1,
v:a(d)})}function g(t,e){return[1,t,e,t*t,t*e,e*e]}for(var p=null,m=l,w=0;w<4&&!(m.length<10);w++){
for(var x=[],v=[0,0,0,0,0,0],y=0;y<6;y++)x.push([0,0,0,0,0,0]);m.forEach(function(t){for(var e=g(t.x,t.y),a=0;a<6;a++){v[a]+=e[a]*t.v
;for(var r=0;r<6;r++)x[a][r]+=e[a]*e[r]}}),p=o(x,v);var b=l.map(function(t){for(var e=g(t.x,t.y),a=0,r=0;r<6;r++)a+=p[r]*e[r];return t.v-a
}),M=1.4826*a(b.map(Math.abs))+1e-30;m=l.filter(function(t,e){return Math.abs(b[e])<3*M})}var S=new Float32Array(r*n);if(!p){
for(var B=a(l.length?l.map(function(t){return t.v}):[0]),A=0;A<S.length;A++)S[A]=B;return S}for(f=0;f<n;f++)for(u=0;u<r;u++){
var P=g(2*(u+.5)/r-1,2*(f+.5)/n-1),z=0;for(y=0;y<6;y++)z+=p[y]*P[y];S[f*r+u]=z}return S}function o(t,e){for(var a=e.length,r=t.map(function(t,a){
return t.concat([e[a]])}),n=0;n<a;n++){for(var o=n,i=n+1;i<a;i++)Math.abs(r[i][n])>Math.abs(r[o][n])&&(o=i);var s=r[n];if(r[n]=r[o],r[o]=s,
!(Math.abs(r[n][n])<1e-300))for(i=n+1;i<a;i++)for(var l=r[i][n]/r[n][n],h=n;h<=a;h++)r[i][h]-=l*r[n][h]}var c=[];for(i=0;i<a;i++)c.push(0);for(i=a-1;i>=0;i--){
var d=r[i][a];for(h=i+1;h<a;h++)d-=r[i][h]*c[h];c[i]=Math.abs(r[i][i])<1e-300?0:d/r[i][i]}return c}function i(t,e,a){
for(var r=new Int32Array(e),n=new Int32Array(e+1),o={area:0,x0:0,y0:0,x1:0,y1:0},i=0;i<a;i++){for(var s=i*e,l=0;l<e;l++)r[l]=t[s+l]?r[l]+1:0;var h=0
;for(l=0;l<=e;l++){for(var c=l<e?r[l]:0;h>0&&r[n[h-1]]>=c;){var d=r[n[--h]],f=h>0?n[h-1]+1:0,u=d*(l-f);u>o.area&&(o={area:u,x0:f,y0:i-d+1,x1:l,y1:i+1})}n[h++]=l
}}return o}function s(t,e,a,r){if(0===r)return{area:(x=i(t,e,a)).area,cx:(x.x0+x.x1)/2,cy:(x.y0+x.y1)/2,w:x.x1-x.x0,h:x.y1-x.y0,angle:0,axis:x}
;for(var n=Math.cos(r),o=Math.sin(r),s=Math.ceil(e*Math.abs(n)+a*Math.abs(o)),l=Math.ceil(e*Math.abs(o)+a*Math.abs(n)),h=new Uint8Array(s*l),c=e/2,d=a/2,f=0;f<l;f++)for(var u=f+.5-l/2,g=0;g<s;g++){
var p=g+.5-s/2,m=Math.floor(c+p*n-u*o),w=Math.floor(d+p*o+u*n);m>=0&&w>=0&&m<e&&w<a&&(h[f*s+g]=t[w*e+m])}var x;return p=((x=i(h,s,l)).x0+x.x1)/2-s/2,
u=(x.y0+x.y1)/2-l/2,{area:x.area,cx:c+p*n-u*o,cy:d+p*o+u*n,w:x.x1-x.x0,h:x.y1-x.y0,angle:r}}var l="SmartCrop",h="1.0.5",c="SmartCrop",d={noiseTolPct:30,
scanPx:300,extraMarginPx:0,allowRotation:!0,maxAngleDeg:10,minGainPct:2};function f(){Settings.write(c+"/noiseTolPct",DataType_Double,d.noiseTolPct),
Settings.write(c+"/scanPx",DataType_Int32,d.scanPx),Settings.write(c+"/extraMarginPx",DataType_Int32,d.extraMarginPx),
Settings.write(c+"/allowRotation",DataType_Boolean,d.allowRotation),Settings.write(c+"/maxAngleDeg",DataType_Double,d.maxAngleDeg),
Settings.write(c+"/minGainPct",DataType_Double,d.minGainPct)}function u(t,e,a,r){if(e.rotated){
var n=e.angleDeg*Math.PI/180,o=Math.abs(Math.cos(n)),i=Math.abs(Math.sin(n)),s=Math.floor(e.width),l=Math.floor(e.height),h=Math.max(s/2,s/2*o+l/2*i),c=Math.max(l/2,s/2*i+l/2*o),d=Math.floor(e.cx-h-8),f=Math.floor(e.cy-c-8),u=Math.ceil(e.cx+h+8),g=Math.ceil(e.cy+c+8)
;t.cropTo(d,f,u,g,r);var p=e.cx-d,m=e.cy-f;t.rotate(a*n,p,m,r);var w=Math.round(p-s/2),x=Math.round(m-l/2);t.cropTo(w,x,w+s,x+l,r)
}else t.cropTo(e.x0,e.y0,e.x1,e.y1,r)}function g(t){
for(var e=t.w,a=t.h,r=t.cell,n=new Float32Array(e*a),o=0;o<a;o++)for(var i=Math.floor(o/r)*t.gw,s=o*e,l=0;l<e;l++)n[s+l]=t.bad[i+Math.floor(l/r)]
;var h=new Image(e,a,1,ColorSpace_Gray);return h.setSamples(n,new Rect(0,0,e,a),0),h}function p(t){
for(var e=[],a=0;a<t.numberOfChannels;a++)e.push(t.toFloat32Array(new Rect(0,0,t.width,t.height),a));return e}function m(t){this.__base__=Control,
this.__base__(t);var e=this;function a(){var t=e.data,a=function(){var t=e.data,a=t.bitmap.width,r=t.bitmap.height;return Math.min(e.width/a,e.height/r)
}()*e.zoom;return{k:a,tx:(e.width-t.bitmap.width*a)/2+e.ox,ty:(e.height-t.bitmap.height*a)/2+e.oy}}this.data=null,this.zoom=1,this.ox=0,this.oy=0,
this.drag=null,this.setScaledMinSize(420,420),this.toolTip="<p>Mouse wheel: zoom &nbsp; Drag: pan &nbsp; Double click: fit</p>",this.onPaint=function(){
var t=new Graphics(this);if(t.fillRect(0,0,this.width,this.height,new Brush(4280295456)),!e.data)return t.pen=new Pen(4288716960),
t.drawTextRect(0,0,this.width,this.height,"Press Analyze to see the crop",TextAlign_Center|TextAlign_VertCenter),void t.end();var r=a(),n=e.data
;t.translateTransformation(r.tx,r.ty),t.scaleTransformation(r.k),t.drawBitmap(0,0,n.bitmap),t.resetTransformation(),t.antialiasing=!0,
t.pen=new Pen(4294956032,2);for(var o=0;o<4;o++){var i=n.corners[o],s=n.corners[(o+1)%4]
;t.drawLine(r.tx+r.k*i.x/n.scale,r.ty+r.k*i.y/n.scale,r.tx+r.k*s.x/n.scale,r.ty+r.k*s.y/n.scale)}t.end()},this.onMouseWheel=function(t,r,n){if(e.data){
var o=a(),i=(t-o.tx)/o.k,s=(r-o.ty)/o.k;if(e.zoom=Math.max(1,Math.min(32,e.zoom*(n>0?1.25:.8))),1===e.zoom)e.ox=e.oy=0;else{var l=a();e.ox+=t-(l.tx+i*l.k),
e.oy+=r-(l.ty+s*l.k)}e.update()}},this.onMousePress=function(t,a){e.drag={x:t,y:a,ox:e.ox,oy:e.oy}},this.onMouseMove=function(t,a){
e.drag&&(e.ox=e.drag.ox+t-e.drag.x,e.oy=e.drag.oy+a-e.drag.y,e.update())},this.onMouseRelease=function(){e.drag=null},this.onMouseDoubleClick=function(){
e.zoom=1,e.ox=e.oy=0,e.update()},this.onResize=function(){e.update()}}function w(t){
for(var e=t.keywords,a=t.mainView.image,r=0;r<e.length;r++)if("HISTORY"===e[r].name){var n=/SmartCrop [^:]*: (\d+)x(\d+) crop/.exec(e[r].comment+" "+e[r].value)
;if(n&&+n[1]===a.width&&+n[2]===a.height)return!0}return!1}function x(){this.__base__=Dialog,this.__base__();var t=this;this.analysis=null
;var e=this.font.width("Max rotation angle (\xb0):")+8;this.helpLabel=new Label(this),this.helpLabel.frameStyle=FrameStyle_Box,this.helpLabel.margin=6,
this.helpLabel.wordWrapping=!0,
this.helpLabel.useRichText=!0,this.helpLabel.text="<b>"+l+" v"+h+"</b> &mdash; tick the registered masters to crop. The script finds black borders and noisy stacking edges on each of them, builds the largest rectangle that is clean on <i>all</i> of them (rotated if that keeps more of the field) and crops every ticked image identically. Each crop can be undone (Ctrl+Z).",
this.tree=new TreeBox(this),this.tree.numberOfColumns=3,this.tree.headerVisible=!0,this.tree.setHeaderText(0,"Image"),this.tree.setHeaderText(1,"Size"),
this.tree.setHeaderText(2,"Channels"),this.tree.rootDecoration=!1,this.tree.alternateRowColor=!0,this.tree.setScaledMinSize(480,200)
;for(var a=ImageWindow.openWindows,r=0;r<a.length;r++)if(!a[r].isNull&&(a[r].visible||a[r].iconic)){var n=a[r].mainView
;if(!n.isNull&&0!==n.id.indexOf("SmartCrop_preview")){var o=new TreeBoxNode(this.tree);o.checkable=!0,o.checked=!0,o.setText(0,n.id),
o.setText(1,n.image.width+" x "+n.image.height),o.setText(2,n.image.isColor?"RGB":"Gray"),o.viewId=n.id}}
for(var i=0;i<3;i++)this.tree.adjustColumnWidthToContents(i);function s(a,r,n,o,i,s,l){var h=new NumericControl(t);return h.label.text=a,h.label.minWidth=e,
h.setRange(r,n),h.slider.setRange(0,Math.round((n-r)*Math.pow(10,Math.min(o,1)))),h.slider.scaledMinWidth=200,h.setPrecision(o),h.setValue(i),h.toolTip=s,
h.onValueUpdated=function(e){l(e),t.invalidate()},h}this.tree.onNodeUpdated=function(){t.invalidate()},this.allButton=new PushButton(this),
this.allButton.text="Select all",this.allButton.onClick=function(){t.setAll(!0)},this.noneButton=new PushButton(this),this.noneButton.text="Select none",
this.noneButton.onClick=function(){t.setAll(!1)},this.listButtons=new HorizontalSizer,this.listButtons.spacing=6,this.listButtons.add(this.allButton),
this.listButtons.add(this.noneButton),
this.listButtons.addStretch(),this.noiseCtl=s("Edge noise tolerance (%):",5,200,0,d.noiseTolPct,"<p>Edges whose noise exceeds the interior noise by more than this are cut off (areas covered by fewer subframes). Lower = stricter crop.</p>",function(t){
d.noiseTolPct=t
}),this.scanCtl=s("Max edge depth (px):",20,1e3,0,d.scanPx,"<p>Noisy edges are searched for no deeper than this from the data border.</p>",function(t){
d.scanPx=Math.round(t)}),this.marginCtl=s("Extra margin (px):",0,200,0,d.extraMarginPx,"<p>Additional safety margin cut from the usable area.</p>",function(t){
d.extraMarginPx=Math.round(t)}),this.rotCheck=new CheckBox(this),this.rotCheck.text="Allow rotated crop",this.rotCheck.checked=d.allowRotation,
this.rotCheck.toolTip="<p>Rotate the crop rectangle (and the images) when this keeps noticeably more of the field.</p>",this.rotCheck.onCheck=function(e){
d.allowRotation=e,t.angleCtl.enabled=t.gainCtl.enabled=e,t.invalidate()
},this.angleCtl=s("Max rotation angle (\xb0):",.5,45,1,d.maxAngleDeg,"<p>Largest rotation tried for the crop rectangle.</p>",function(t){d.maxAngleDeg=t}),
this.gainCtl=s("Min area gain (%):",0,20,1,d.minGainPct,"<p>Rotate only if the rotated crop is at least this much larger than the best axis-aligned one (rotation resamples the images).</p>",function(t){
d.minGainPct=t}),this.angleCtl.enabled=this.gainCtl.enabled=d.allowRotation,this.paramBox=new GroupBox(this),this.paramBox.title="Parameters",
this.paramBox.sizer=new VerticalSizer,this.paramBox.sizer.margin=6,this.paramBox.sizer.spacing=4,this.paramBox.sizer.add(this.noiseCtl),
this.paramBox.sizer.add(this.scanCtl),this.paramBox.sizer.add(this.marginCtl),this.paramBox.sizer.add(this.rotCheck),this.paramBox.sizer.add(this.angleCtl),
this.paramBox.sizer.add(this.gainCtl),this.resultLabel=new Label(this),this.resultLabel.frameStyle=FrameStyle_Sunken,this.resultLabel.margin=6,
this.resultLabel.wordWrapping=!0,this.resultLabel.text="Press Analyze to compute the crop.",this.resultLabel.setScaledMinHeight(48),
this.analyzeButton=new PushButton(this),this.analyzeButton.text="Analyze",this.analyzeButton.icon=this.scaledResource(":/icons/find.png"),
this.analyzeButton.onClick=function(){t.analyze()},this.applyButton=new PushButton(this),this.applyButton.text="Crop",
this.applyButton.icon=this.scaledResource(":/icons/ok.png"),this.applyButton.toolTip="<p>Crop all ticked images (analyzes first if needed).</p>",
this.applyButton.onClick=function(){t.apply()},this.closeButton=new PushButton(this),this.closeButton.text="Close",
this.closeButton.icon=this.scaledResource(":/icons/close.png"),this.closeButton.onClick=function(){t.cancel()},this.heartLabel=new Label(this),
this.heartLabel.useRichText=!0,this.heartLabel.text='<span style="color:#e0245e; font-size:15pt;">&#9829;</span>',
this.heartLabel.toolTip="<p>Like SmartCrop? Support its development with a donation (PayPal).</p>",this.heartLabel.cursor=new Cursor(StdCursor_PointingHand),
this.heartLabel.onMousePress=function(){
Dialog.openBrowser("https://www.paypal.com/donate/?business=contact%40bluebelleweddings.com&no_recurring=0&item_name=SmartCrop")},
this.buttons=new HorizontalSizer,this.buttons.spacing=6,this.buttons.add(this.heartLabel),this.buttons.addStretch(),this.buttons.add(this.analyzeButton),
this.buttons.add(this.applyButton),this.buttons.add(this.closeButton),this.preview=new m(this),this.leftSizer=new VerticalSizer,this.leftSizer.spacing=6,
this.leftSizer.add(this.helpLabel),this.leftSizer.add(this.tree,100),this.leftSizer.add(this.listButtons),this.leftSizer.add(this.paramBox),
this.leftSizer.add(this.resultLabel),this.leftSizer.add(this.buttons),this.sizer=new HorizontalSizer,this.sizer.margin=8,this.sizer.spacing=8,
this.sizer.add(this.leftSizer),this.sizer.add(this.preview,100),this.windowTitle=l+" v"+h,this.adjustToContents(),this.setScaledMinSize(1e3,620)}
m.prototype=new Control,m.prototype.setData=function(t){this.data=t,this.zoom=1,this.ox=this.oy=0,this.update()},x.prototype=new Dialog,
x.prototype.setAll=function(t){for(var e=0;e<this.tree.numberOfChildren;e++)this.tree.child(e).checked=t;this.invalidate()},x.prototype.invalidate=function(){
this.analysis&&(this.resultLabel.text="Parameters or selection changed - press Analyze again.",this.preview.setData(null)),this.analysis=null},
x.prototype.selectedViews=function(){for(var t=[],e=0;e<this.tree.numberOfChildren;e++){var a=this.tree.child(e);if(a.checked){var r=View.viewById(a.viewId)
;r&&!r.isNull&&t.push(r)}}return t},x.prototype.analyze=function(){var t=this.selectedViews()
;if(0===t.length)return new MessageBox("Tick at least one image.",l,StdIcon_Warning,StdButton_Ok).execute(),!1
;for(var n,o,i,c=[],f=0;f<t.length;f++)w(t[f].window)&&c.push(t[f].id)
;if(c.length>0&&new MessageBox("Already cropped by SmartCrop:\n   "+c.join("\n   ")+"\n\nAnalyze again anyway? A second pass may trim the edges a little more.",l,StdIcon_Question,StdButton_Yes,StdButton_No).execute()!==StdButton_Yes)return!1
;this.enabled=!1,console.show(),console.abortEnabled=!0;try{console.noteln("<end><cbr><br>"+l+" v"+h+": "+t.length+" image(s)");var m=Date.now()
;this.analysis=function(t){for(var a={noiseTol:d.noiseTolPct/100,scanPx:d.scanPx,extraMarginPx:d.extraMarginPx,allowRotation:d.allowRotation,
maxAngleDeg:d.maxAngleDeg,minGainPct:d.minGainPct},n=[],o=t[0].image.width,i=t[0].image.height,l=0;l<t.length;l++){var h=t[l].image
;if(h.width!==o||h.height!==i)throw new Error(t[l].id+" is "+h.width+"x"+h.height+", but "+t[0].id+" is "+o+"x"+i+". All images must be registered to the same frame.")
}for(l=0;l<t.length;l++){var c=Date.now();console.write("<end><cbr>Analyzing "+t[l].id+" ... "),processEvents();var f=r(p(t[l].image),o,i,a);f.id=t[l].id,
console.writeln(format("good %.1f%% (no data %.1f%%, noisy edges %.1f%%)  %.1f s",100*f.goodFrac,100*f.noDataFrac,100*f.artifactFrac,(Date.now()-c)/1e3))
;for(var m=0;m<f.notes.length;m++)console.warningln("   ** "+f.notes[m]);n.push(f),processEvents(),gc()}var w=function(t){
for(var e=t[0],a=new Uint8Array(e.bad.length),r=0;r<t.length;r++){var n=t[r];if(n.w!==e.w||n.h!==e.h)throw new Error("Images have different dimensions")
;for(var o=0;o<a.length;o++)a[o]|=n.bad[o]}return{cell:e.cell,gw:e.gw,gh:e.gh,w:e.w,h:e.h,bad:a}}(n);console.write("Searching for the best crop ... "),
processEvents();var x=function(t,a){a=e(a);for(var r=t.gw,n=t.gh,o=t.cell,i=r*n,l=new Uint8Array(i),h=0;h<i;h++)l[h]=t.bad[h]?0:1;var c=s(l,r,n,0)
;if(0===c.area)throw new Error("No usable area common to all images");var d=c.axis,f={x0:d.x0*o,y0:d.y0*o,x1:Math.min(t.w,d.x1*o),y1:Math.min(t.h,d.y1*o),
angleDeg:0,rotated:!1};if(f.width=f.x1-f.x0,f.height=f.y1-f.y0,f.cx=(f.x0+f.x1)/2,f.cy=(f.y0+f.y1)/2,f.axisAreaFrac=f.areaFrac=f.width*f.height/(t.w*t.h),
!a.allowRotation||a.maxAngleDeg<=0)return f;for(var u=new Uint8Array(i),g=0;g<n;g++)for(var p=0;p<r;p++){
for(var m=l[g*r+p],w=-1;w<=1&&m;w++)for(var x=-1;x<=1&&m;x++){var v=p+x,y=g+w;(v<0||y<0||v>=r||y>=n||!l[y*r+v])&&(m=0)}u[g*r+p]=m}var b=Math.PI/180,M=null
;function S(t){if(0!==t){var e=s(u,r,n,t*b);(!M||e.area>M.area)&&(M=e)}}for(var B=.25,A=-a.maxAngleDeg;A<=a.maxAngleDeg+1e-9;A+=B)S(Math.round(1e3*A)/1e3)
;if(!M)return f;var P=M.angle/b;for(A=P-B;A<=P+B+1e-9;A+=.02)S(Math.round(1e3*A)/1e3);var z=M.w*o,C=M.h*o,T=z*C/(t.w*t.h)
;return T>=f.axisAreaFrac*(1+a.minGainPct/100)?f={cx:M.cx*o,cy:M.cy*o,width:z,height:C,angleDeg:M.angle/b,rotated:!0,areaFrac:T,axisAreaFrac:f.axisAreaFrac
}:(f.bestRotatedFrac=T,f.bestRotatedDeg=M.angle/b),f}(w,a);console.writeln("done");var v=function(t,e){for(var a=e.rotated?[1,-1]:[1],r=0;r<a.length;r++){
var n=g(t);n.interpolation=Interpolation_Bilinear,u(n,e,a[r],[1]);var o=n.maximum()<.5&&n.width===Math.floor(e.width)&&n.height===Math.floor(e.height)
;if(n.free(),o)return a[r]}return 0}(w,x);if(0===v)throw new Error("Internal check failed: the computed crop would include bad pixels. Nothing was changed.")
;x.sign=v;var y=n[0];for(l=1;l<n.length;l++)n[l].goodFrac<y.goodFrac&&(y=n[l]);return{list:n,comb:w,plan:x,worst:y}}(t),this.analysis.ids=t.map(function(t){
return t.id}).join("|");var x=(o=(n=this.analysis).plan,i=format("%d x %d px",Math.floor(o.width),Math.floor(o.height)),
o.rotated?i+=format(", frame tilted %.2f\xb0 %s",Math.abs(o.angleDeg),o.angleDeg>0?"clockwise":"counter-clockwise"):i+=", no rotation",
i+=format(", keeps %.1f%% of the frame",100*o.areaFrac),
o.rotated?i+=format(" (axis-aligned: %.1f%%)",100*o.axisAreaFrac):void 0!==o.bestRotatedFrac&&d.allowRotation&&(i+=format(" (rotation would give only %.1f%%)",100*o.bestRotatedFrac)),
i+"\nMost limiting image: "+n.worst.id+format(" (%.1f%% usable)",100*n.worst.goodFrac));console.noteln(x),
console.writeln(format("Analysis time %.1f s",(Date.now()-m)/1e3)),this.resultLabel.text=x;var v=function(t,e){
for(var r=t.comb,n=r.w,o=r.h,i=r.cell,s=e[0],l=0;l<e.length;l++)e[l].id===t.worst.id&&(s=e[l])
;for(var h=Math.max(1,Math.ceil(Math.max(n,o)/1400)),c=Math.floor(n/h),d=Math.floor(o/h),f=c*d,u=p(s.image),g=u.length,m=new Float32Array(f),w=0;w<d;w++)for(var x=0;x<c;x++){
for(var v=0,y=0;y<h;y++)for(var b=(w*h+y)*n+x*h,M=0;M<h;M++)for(var S=0;S<g;S++)v+=u[S][b+M];m[w*c+x]=v/(h*h*g)}u=null;var B=[]
;for(l=0;l<f;l+=7)m[l]>0&&B.push(m[l]);var A=a(B),P=1.4826*a(B.map(function(t){return Math.abs(t-A)})),z=Math.max(0,A-2.8*P),C=Math.max(1e-6,1-z)
;function T(t,e){return e<=0?0:e>=1?1:(t-1)*e/((2*t-1)*e-t)}var D=T(.25,(A-z)/C),k=new Float32Array(f),_=new Float32Array(f),R=new Float32Array(f)
;for(w=0;w<d;w++){var F=Math.floor((w*h+h/2)/i)*r.gw;for(x=0;x<c;x++){var I=T(D,(m[l=w*c+x]-z)/C);r.bad[F+Math.floor((x*h+h/2)/i)]?(k[l]=.35+.5*I,_[l]=.4*I,
R[l]=.4*I):k[l]=_[l]=R[l]=I}}var L=new Image(c,d,3,ColorSpace_RGB);L.setSamples(k,new Rect(0,0,c,d),0),L.setSamples(_,new Rect(0,0,c,d),1),
L.setSamples(R,new Rect(0,0,c,d),2);var E=L.render();return L.free(),{bitmap:E,scale:h}}(this.analysis,t);return v.corners=function(t){
var e=t.angleDeg*Math.PI/180,a=Math.cos(e),r=Math.sin(e),n=t.width/2,o=t.height/2;return[[-n,-o],[n,-o],[n,o],[-n,o]].map(function(e){return{
x:t.cx+e[0]*a-e[1]*r,y:t.cy+e[0]*r+e[1]*a}})}(this.analysis.plan),this.preview.setData(v),!0}catch(t){return this.analysis=null,
console.criticalln(t.toString()),this.resultLabel.text="Error: "+t.toString(),new MessageBox(t.toString(),l,StdIcon_Error,StdButton_Ok).execute(),!1}finally{
console.abortEnabled=!1,this.enabled=!0}},x.prototype.apply=function(){var t=this.selectedViews(),e=t.map(function(t){return t.id}).join("|")
;if(this.analysis&&this.analysis.ids===e||this.analyze()){this.enabled=!1;try{!function(t,e){for(var a=e.plan,r=0;r<t.length;r++){var n=t[r],o=n.window
;console.writeln("Cropping "+n.id),processEvents();for(var i=n.image.numberOfChannels,s=[],l=0;l<i;l++)s.push(0);var c=o.hasAstrometricSolution
;n.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{n.image.interpolation=Interpolation_Lanczos3,u(n.image,a,a.sign,s)
;var d=o.keywords
;d.push(new FITSKeyword("HISTORY","",format("SmartCrop %s: %dx%d crop, angle %.3f deg",h,Math.floor(a.width),Math.floor(a.height),a.rotated?a.angleDeg:0))),
o.keywords=d,c&&o.clearAstrometricSolution()}finally{n.endProcess()}
c&&console.warningln("   ** astrometric solution removed (geometry changed) - re-solve the image if needed")}}(t,this.analysis),
console.noteln("<end><cbr>"+l+": "+t.length+" image(s) cropped."),f(),this.ok()}catch(t){console.criticalln(t.toString()),
new MessageBox(t.toString(),l,StdIcon_Error,StdButton_Ok).execute(),this.enabled=!0}}},console.hide(),0!==ImageWindow.openWindows.length?(function(){
function t(t,e,a){var r=Settings.read(c+"/"+t,e);return Settings.lastReadOK?r:a}d.noiseTolPct=t("noiseTolPct",DataType_Double,d.noiseTolPct),
d.scanPx=t("scanPx",DataType_Int32,d.scanPx),d.extraMarginPx=t("extraMarginPx",DataType_Int32,d.extraMarginPx),
d.allowRotation=t("allowRotation",DataType_Boolean,d.allowRotation),d.maxAngleDeg=t("maxAngleDeg",DataType_Double,d.maxAngleDeg),
d.minGainPct=t("minGainPct",DataType_Double,d.minGainPct)
}(),(new x).execute(),f()):new MessageBox("Open the registered master frames first.",l,StdIcon_Information,StdButton_Ok).execute()}();
