// SmartCrop 1.2.2 for PixInsight - Copyright (c) 2026 BananAndrews. All rights reserved.
// Free to use. Modification, reverse engineering and redistribution of modified versions are not permitted.
#feature-id    SmartCrop : Utilities > SmartCrop
#feature-info  Synchronized automatic crop of master frames.<br/>\
   Detects black borders and noisy stacking edges on every selected image, \
   finds the largest rectangle (at any angle) with good data on all of them \
   and crops all images identically. Can register unregistered masters first \
   (by stars or by their astrometric solutions).
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/Interpolation.jsh>
!function(){var t={zeroLevel:0,noiseTol:.3,darkTolSigma:0,scanPx:300,voteRadius:5,extraMarginPx:0,allowRotation:!0,minGainPct:2};function e(e){var a={}
;for(var r in t)a[r]=t[r];if(e)for(var n in e)a[n]=e[n];return a}function a(t,e){return Math.max(2,Math.round(Math.max(t,e)/1e3))}function r(t,e){
if(void 0===e&&(e=t.length),0===e)return NaN;var a=Array.prototype.slice.call(t,0,e).sort(function(t,e){return t-e});return 1&e?a[e>>1]:.5*(a[(e>>1)-1]+a[e>>1])
}function n(t,n,o,s){s=e(s)
;for(var h=a(n,o),l=Math.ceil(n/h),c=Math.ceil(o/h),d=l*c,u=t.length,f=new Uint8Array(d),g=new Float32Array(d),w=new Float32Array(d),m=new Float32Array(n),p=new Uint8Array(n),v=new Float64Array(l),y=new Float64Array(l),x=new Int32Array(l),b=new Int32Array(l),M=0;M<c;M++){
for(var S=0;S<l;S++)v[S]=0,y[S]=0,x[S]=0,b[S]=0;for(var P=Math.min(o,(M+1)*h),C=M*h;C<P;C++){for(var B=C*n,A=0;A<n;A++){for(var z=0,_=0,k=0;k<u;k++){
var T=t[k][B+A];T>s.zeroLevel||(_=1),z+=T}m[A]=z/u,p[A]=_}for(S=0;S<l;S++){var F=S*h,R=Math.min(n,F+h),I=M*l+S;for(A=F;A<R;A++)p[A]&&(f[I]=1),v[S]+=m[A],x[S]++,
A+1<R&&(y[S]+=Math.abs(m[A+1]-m[A]),b[S]++)}}for(S=0;S<l;S++)g[I=M*l+S]=v[S]/Math.max(1,x[S]),w[I]=y[S]/Math.max(1,b[S])}
var D=new Uint8Array(d),L=new Int32Array(d),U=0,V=0;function E(t){f[t]&&!D[t]&&(D[t]=1,L[V++]=t)}for(S=0;S<l;S++)E(S),E((c-1)*l+S);for(M=0;M<c;M++)E(M*l),
E(M*l+l-1);for(;U<V;)for(var G=((j=L[U++])-(wt=j%l))/l,O=-1;O<=1;O++)for(var W=-1;W<=1;W++){var N=G+O;(mt=wt+W)>=0&&N>=0&&mt<l&&N<c&&E(N*l+mt)}
for(var H=new Float32Array(d),j=0;j<d;j++)H[j]=D[j]?0:1e9;function K(t,e){return t<0||e<0||t>=l||e>=c?0:H[e*l+t]}
for(C=0;C<c;C++)for(A=0;A<l;A++)0!==H[j=C*l+A]&&(H[j]=Math.min(H[j],K(A-1,C)+3,K(A,C-1)+3,K(A-1,C-1)+4,K(A+1,C-1)+4))
;for(C=c-1;C>=0;C--)for(A=l-1;A>=0;A--)0!==H[j=C*l+A]&&(H[j]=Math.min(H[j],K(A+1,C)+3,K(A,C+1)+3,K(A+1,C+1)+4,K(A-1,C+1)+4));var Y=new Int32Array(d)
;for(j=0;j<d;j++)Y[j]=D[j]?0:Math.max(1,Math.round(H[j]/3))
;var q=Math.max(4,Math.round(s.scanPx/h)),Q=i(g,Y,l,c,q),Z=i(w,Y,l,c,q),$=r(Array.prototype.filter.call(Z,function(t,e){return!D[e]})),J=new Uint8Array(d)
;for(j=0;j<d;j++)if(!(D[j]||Y[j]>q+s.voteRadius)){var X=Math.max(Z[j],.25*$),tt=X/1.128
;(w[j]>(1+s.noiseTol)*X||s.darkTolSigma>0&&g[j]<Q[j]-s.darkTolSigma*tt)&&(J[j]=1)}
var et=s.voteRadius,at=l+1,rt=new Int32Array(at*(c+1)),nt=new Int32Array(at*(c+1));for(C=0;C<c;C++){var it=0,ot=0;for(A=0;A<l;A++){var st=(C+1)*at+A+1
;it+=J[j=C*l+A],ot+=D[j]?0:1,rt[st]=rt[st-at]+it,nt[st]=nt[st-at]+ot}}var ht=new Uint8Array(d);for(C=0;C<c;C++)for(A=0;A<l;A++)if(!(D[j=C*l+A]||Y[j]>q)){
var lt=Math.max(0,A-et),ct=Math.min(l,A+et+1),dt=Math.max(0,C-et),ut=Math.min(c,C+et+1)
;2*(rt[ut*at+ct]-rt[dt*at+ct]-rt[ut*at+lt]+rt[dt*at+lt])>nt[ut*at+ct]-nt[dt*at+ct]-nt[ut*at+lt]+nt[dt*at+lt]&&(ht[j]=1)}var ft=new Uint8Array(d);for(U=V=0,
j=0;j<d;j++)D[j]&&(ft[j]=1,L[V++]=j);function gt(t){ht[t]&&!ft[t]&&(ft[t]=1,L[V++]=t)}for(S=0;S<l;S++)gt(S),gt((c-1)*l+S);for(M=0;M<c;M++)gt(M*l),gt(M*l+l-1)
;for(;U<V;){var wt;for(G=((j=L[U++])-(wt=j%l))/l,O=-1;O<=1;O++)for(W=-1;W<=1;W++){var mt;N=G+O,(mt=wt+W)>=0&&N>=0&&mt<l&&N<c&&gt(N*l+mt)}}
var pt=Math.ceil(s.extraMarginPx/h),vt=0,yt=0,xt=[];for(j=0;j<d;j++)ft[j]&&!D[j]&&yt++,!ft[j]&&pt>0&&Y[j]<=pt&&(ft[j]=1),ft[j]||vt++;var bt=0
;for(j=0;j<d;j++)bt+=D[j];var Mt=0;for(j=0;j<d;j++)ft[j]&&!D[j]&&Y[j]>=q&&Mt++;return Mt>0&&xt.push("edge artifacts reach the "+s.scanPx+" px scan limit"),{
cell:h,gw:l,gh:c,w:n,h:o,bad:ft,goodFrac:vt/d,noDataFrac:bt/d,artifactFrac:yt/d,noiseRef:$,notes:xt,outside:D}}function i(t,e,a,n,i){
for(var s=Math.max(8,Math.round(Math.max(a,n)/24)),h=[],l=0;l<n;l+=s)for(var c=0;c<a;c+=s){
for(var d=[],u=l;u<Math.min(n,l+s);u++)for(var f=c;f<Math.min(a,c+s);f++)e[C=u*a+f]>i&&d.push(t[C]);d.length>=s*s/2&&h.push({x:2*(c+s/2)/a-1,y:2*(l+s/2)/n-1,
v:r(d)})}function g(t,e){return[1,t,e,t*t,t*e,e*e]}for(var w=null,m=h,p=0;p<4&&!(m.length<10);p++){
for(var v=[],y=[0,0,0,0,0,0],x=0;x<6;x++)v.push([0,0,0,0,0,0]);m.forEach(function(t){for(var e=g(t.x,t.y),a=0;a<6;a++){y[a]+=e[a]*t.v
;for(var r=0;r<6;r++)v[a][r]+=e[a]*e[r]}}),w=o(v,y);var b=h.map(function(t){for(var e=g(t.x,t.y),a=0,r=0;r<6;r++)a+=w[r]*e[r];return t.v-a
}),M=1.4826*r(b.map(Math.abs))+1e-30;m=h.filter(function(t,e){return Math.abs(b[e])<3*M})}var S=new Float32Array(a*n);if(!w){
for(var P=r(h.length?h.map(function(t){return t.v}):[0]),C=0;C<S.length;C++)S[C]=P;return S}for(u=0;u<n;u++)for(f=0;f<a;f++){
var B=g(2*(f+.5)/a-1,2*(u+.5)/n-1),A=0;for(x=0;x<6;x++)A+=w[x]*B[x];S[u*a+f]=A}return S}function o(t,e){for(var a=e.length,r=t.map(function(t,a){
return t.concat([e[a]])}),n=0;n<a;n++){for(var i=n,o=n+1;o<a;o++)Math.abs(r[o][n])>Math.abs(r[i][n])&&(i=o);var s=r[n];if(r[n]=r[i],r[i]=s,
!(Math.abs(r[n][n])<1e-300))for(o=n+1;o<a;o++)for(var h=r[o][n]/r[n][n],l=n;l<=a;l++)r[o][l]-=h*r[n][l]}var c=[];for(o=0;o<a;o++)c.push(0);for(o=a-1;o>=0;o--){
var d=r[o][a];for(l=o+1;l<a;l++)d-=r[o][l]*c[l];c[o]=Math.abs(r[o][o])<1e-300?0:d/r[o][o]}return c}function s(t,e,a){
for(var r=new Int32Array(e),n=new Int32Array(e+1),i={area:0,x0:0,y0:0,x1:0,y1:0},o=0;o<a;o++){for(var s=o*e,h=0;h<e;h++)r[h]=t[s+h]?r[h]+1:0;var l=0
;for(h=0;h<=e;h++){for(var c=h<e?r[h]:0;l>0&&r[n[l-1]]>=c;){var d=r[n[--l]],u=l>0?n[l-1]+1:0,f=d*(h-u);f>i.area&&(i={area:f,x0:u,y0:o-d+1,x1:h,y1:o+1})}n[l++]=h
}}return i}function h(t,e,a,r){if(0===r)return{area:(v=s(t,e,a)).area,cx:(v.x0+v.x1)/2,cy:(v.y0+v.y1)/2,w:v.x1-v.x0,h:v.y1-v.y0,angle:0,axis:v}
;for(var n=Math.cos(r),i=Math.sin(r),o=Math.ceil(e*Math.abs(n)+a*Math.abs(i)),h=Math.ceil(e*Math.abs(i)+a*Math.abs(n)),l=new Uint8Array(o*h),c=e/2,d=a/2,u=0;u<h;u++)for(var f=u+.5-h/2,g=0;g<o;g++){
var w=g+.5-o/2,m=Math.floor(c+w*n-f*i),p=Math.floor(d+w*i+f*n);m>=0&&p>=0&&m<e&&p<a&&(l[u*o+g]=t[p*e+m])}var v;return w=((v=s(l,o,h)).x0+v.x1)/2-o/2,
f=(v.y0+v.y1)/2-h/2,{area:v.area,cx:c+w*n-f*i,cy:d+w*i+f*n,w:v.x1-v.x0,h:v.y1-v.y0,angle:r}}function l(t,e,a,r){
for(var n=Math.floor(e/r),i=Math.floor(a/r),o=new Uint8Array(n*i),s=0;s<i;s++)for(var h=0;h<n;h++){
for(var l=1,c=0;c<r&&l;c++)for(var d=0;d<r;d++)if(!t[(s*r+c)*e+h*r+d]){l=0;break}o[s*n+h]=l}return{g:o,w:n,h:i}}function c(t,e,a,r){
for(var n=[],i=[],o=2;o<a-2;o++)for(var s=2;s<e-2;s++)!t[v=o*e+s]||t[v-1]&&t[v+1]&&t[v-e]&&t[v+e]||(n.push(s),i.push(o));var h=n.length;if(h<20)return null
;if(h>6e3){for(var l=h/6e3,c=[],d=[],u=0;u<h;u+=l)c.push(n[Math.floor(u)]),d.push(i[Math.floor(u)]);i=d,h=(n=c).length}
var f=Math.ceil(Math.sqrt(e*e+a*a))+2,g=new Float64Array(2*f+1);function w(t){for(var e=t*Math.PI/180,a=Math.cos(e),r=Math.sin(e),o=0,s=0;s<2;s++){
for(var l=0;l<g.length;l++)g[l]=0;for(l=0;l<h;l++){var c=0===s?n[l]*a+i[l]*r:-n[l]*r+i[l]*a;g[Math.round(c/2)+f]++}for(l=0;l<g.length;l++)o+=g[l]*g[l]}return o}
var m=0,p=-1;if(r&&r.length){for(var v=0;v<r.length;v++)(b=w(r[v]))>p&&(p=b,m=r[v]);return m=(m%90+135)%90-45,Math.round(100*m)/100}
for(var y=-45;y<45;y+=.5)(b=w(y))>p&&(p=b,m=y);var x=m;for(y=x-.5;y<=x+.5+1e-9;y+=.05){var b;(b=w(y))>p&&(p=b,m=y)}
return(m=Math.round(100*m)/100)>=45?m-90:m<-45?m+90:m}
var d="SmartCrop",u="1.2.2",f="SmartCrop",g=[[1,"https://api.bepaid.by/products/prd_e9ae5ef19bddc47d/pay"],[3,"https://api.bepaid.by/products/prd_29731c50851f55a8/pay"],[5,"https://api.bepaid.by/products/prd_f2c63d66f7cfe15b/pay"],[10,"https://api.bepaid.by/products/prd_424196484db864d0/pay"]],w={
noiseTolPct:30,scanPx:300,extraMarginPx:0,allowRotation:!0,minGainPct:2};function m(){Settings.write(f+"/noiseTolPct",DataType_Double,w.noiseTolPct),
Settings.write(f+"/scanPx",DataType_Int32,w.scanPx),Settings.write(f+"/extraMarginPx",DataType_Int32,w.extraMarginPx),
Settings.write(f+"/allowRotation",DataType_Boolean,w.allowRotation),Settings.write(f+"/minGainPct",DataType_Double,w.minGainPct)}function p(){return{
noiseTol:w.noiseTolPct/100,scanPx:w.scanPx,extraMarginPx:w.extraMarginPx,allowRotation:w.allowRotation,minGainPct:w.minGainPct}}function v(t,e,a,r){
if(e.rotated){
var n=e.angleDeg*Math.PI/180,i=Math.abs(Math.cos(n)),o=Math.abs(Math.sin(n)),s=Math.floor(e.width),h=Math.floor(e.height),l=Math.max(s/2,s/2*i+h/2*o),c=Math.max(h/2,s/2*o+h/2*i),d=Math.floor(e.cx-l-8),u=Math.floor(e.cy-c-8),f=Math.ceil(e.cx+l+8),g=Math.ceil(e.cy+c+8)
;t.cropTo(d,u,f,g,r);var w=e.cx-d,m=e.cy-u;t.rotate(a*n,w,m,r);var p=Math.round(w-s/2),v=Math.round(m-h/2);t.cropTo(p,v,p+s,v+h,r)
}else t.cropTo(e.x0,e.y0,e.x1,e.y1,r)}function y(t){
for(var e=t.w,a=t.h,r=t.cell,n=new Float32Array(e*a),i=0;i<a;i++)for(var o=Math.floor(i/r)*t.gw,s=i*e,h=0;h<e;h++)n[s+h]=t.bad[o+Math.floor(h/r)]
;var l=new Image(e,a,1,ColorSpace_Gray);return l.setSamples(n,new Rect(0,0,e,a),0),l}function x(t,e){
var a=t.image,r=new ImageWindow(a.width,a.height,a.numberOfChannels,32,!0,a.isColor,e);return r.mainView.beginProcess(UndoFlag_NoSwapFile),
r.mainView.image.assign(a),r.mainView.endProcess(),t.window.hasAstrometricSolution&&r.copyAstrometricSolution(t.window),r}function b(t,e,a){
for(var r={},n=ImageWindow.windows,i=0;i<n.length;i++)r[n[i].mainView.id]=!0;var o=new StarAlignment;o.referenceImage=e.id,o.referenceIsFile=!1;try{
o.noGUIMessages=!0}catch(t){}var s=!1;try{s=o.executeOn(t,!1)}catch(t){s=!1}if(a){a.angle=null;try{var h=o.outputData,l=h&&h.length?h[h.length-1]:null
;l&&isFinite(l[11])&&isFinite(l[14])&&(0!==l[11]||0!==l[14])&&(a.angle=180*Math.atan2(l[14],l[11])/Math.PI)}catch(t){}}var c=null;for(n=ImageWindow.windows,
i=0;i<n.length;i++){var d=n[i].mainView.id;r[d]||n[i].isNull||c&&0!==d.indexOf(t.id)||(c=n[i])}if(!c)return!1
;var u=s&&c.mainView.image.width===e.image.width&&c.mainView.image.height===e.image.height;if(u){
t.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{t.image.assign(c.mainView.image)}finally{t.endProcess()}
e.window.hasAstrometricSolution&&t.window.copyAstrometricSolution(e.window)}return c.forceClose(),u}function M(t,e,a){var r=null;try{r=t.imageToCelestial(e,a)
}catch(n){try{r=t.imageToCelestial(new Point(e,a))}catch(t){r=null}}return r&&isFinite(r.x)&&isFinite(r.y)?r:null}function S(t,e,a){var r=null;try{
r=t.celestialToImage(e,a)}catch(n){try{r=t.celestialToImage(new Point(e,a))}catch(t){r=null}}return r&&isFinite(r.x)&&isFinite(r.y)?r:null}
function P(t,e,a,r,n){for(var i=t.mainView.image,o=i.width,s=i.height,h=[],l=[[0,0,o,0],[o,0,o,s],[o,s,0,s],[0,s,0,0]],c=0;c<4;c++)for(var d=0;d<32;d++){
var u=d/32,f=M(t,l[c][0]+u*(l[c][2]-l[c][0]),l[c][1]+u*(l[c][3]-l[c][1])),g=f?S(e,f.x,f.y):null
;if(!g)throw new Error("Cannot map "+t.mainView.id+" onto "+e.mainView.id+" with the astrometric solutions.");h.push({x:g.x/n,y:g.y/n})}return function(t,e,a){
for(var r=new Uint8Array(e*a),n=t.length,i=0;i<a;i++){for(var o=i+.5,s=[],h=0;h<n;h++){var l=t[h],c=t[(h+1)%n]
;l.y<=o!=c.y<=o&&s.push(l.x+(o-l.y)*(c.x-l.x)/(c.y-l.y))}s.sort(function(t,e){return t-e})
;for(var d=0;d+1<s.length;d+=2)for(var u=Math.max(0,Math.ceil(s[d]-.5)),f=Math.min(e-1,Math.floor(s[d+1]-.5)),g=u;g<=f;g++)r[i*e+g]=1}return r}(h,a,r)}
function C(t,e){var a=t.mainView.image,r=a.width/2,n=a.height/2,i=M(t,r,n),o=M(t,r+100,n),s=i?S(e,i.x,i.y):null,h=o?S(e,o.x,o.y):null
;return s&&h?180*Math.atan2(h.y-s.y,h.x-s.x)/Math.PI:null}function B(t,e){
var a=e.image,r=t.image.numberOfChannels,n=null,i=new ImageWindow(a.width,a.height,r,32,!0,r>=3,"SmartCrop_reproject");try{i.copyAstrometricSolution(e.window)
;for(var o=[function(){i.astrometricReprojection(t.window,new Point(0,0),!0)},function(){i.astrometricReprojection(t.window)},function(){
i.astrometricReprojection(t.window,new Point(0,0))}],s=0;s<o.length&&!n;s++)try{o[s]();var h=i.mainView.image
;h.width===a.width&&h.height===a.height&&h.maximum()>0&&(n=new Image(h))}catch(t){}}finally{i.forceClose()}
if(n||(console.writeln("   (resampling "+t.id+" through the astrometric solutions)"),n=function(t,e){
for(var a=t.image,r=e.image,n=r.width,i=r.height,o=a.width,s=a.height,h=a.numberOfChannels,l=32,c=Math.ceil(n/l)+1,d=Math.ceil(i/l)+1,u=new Float64Array(c*d),f=new Float64Array(c*d),g=new Uint8Array(c*d),w=0;w<d;w++)for(var m=0;m<c;m++){
var p=M(e.window,m*l+.5,w*l+.5),v=p?S(t.window,p.x,p.y):null;v&&(u[w*c+m]=v.x-.5,f[w*c+m]=v.y-.5,g[w*c+m]=1)}
for(var y=A(a),x=[],b=0;b<h;b++)x.push(new Float32Array(n*i));function P(t,e,a,r,n){return a+.5*t*(r-e+t*(2*e-5*a+4*r-n+t*(3*(a-r)+n-e)))}for(var C=0;C<i;C++){
255&C||processEvents();for(var B=C/l,z=Math.min(d-2,Math.floor(B)),_=B-z,k=0;k<n;k++){var T=k/l,F=Math.min(c-2,Math.floor(T)),R=T-F,I=z*c+F,D=I+1,L=I+c,U=L+1
;if(g[I]&&g[D]&&g[L]&&g[U]){
var V=(u[I]*(1-R)+u[D]*R)*(1-_)+(u[L]*(1-R)+u[U]*R)*_,E=(f[I]*(1-R)+f[D]*R)*(1-_)+(f[L]*(1-R)+f[U]*R)*_,G=Math.floor(V),O=Math.floor(E)
;if(!(G<1||O<1||G>o-3||O>s-3)){var W=V-G,N=E-O,H=C*n+k;for(b=0;b<h;b++){for(var j=y[b],K=(O-1)*o+G-1,Y=[],q=0;q<4;q++,
K+=o)Y.push(P(W,j[K],j[K+1],j[K+2],j[K+3]))
;var Q=P(N,Y[0],Y[1],Y[2],Y[3]),Z=O*o+G,$=Math.min(j[Z],j[Z+1],j[Z+o],j[Z+o+1]),J=Math.max(j[Z],j[Z+1],j[Z+o],j[Z+o+1]);x[b][H]=Q<$?$:Q>J?J:Q}}}}}y=null
;var X=new Image(n,i,h,h>=3?ColorSpace_RGB:ColorSpace_Gray);for(b=0;b<h;b++)X.setSamples(x[b],new Rect(0,0,n,i),b);return X}(t,e)),!n)return!1
;t.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{t.image.assign(n)}finally{t.endProcess()}return n.free(),
t.window.copyAstrometricSolution(e.window),t.image.width===a.width&&t.image.height===a.height}function A(t){
for(var e=[],a=0;a<t.numberOfChannels;a++)e.push(t.toFloat32Array(new Rect(0,0,t.width,t.height),a));return e}function z(t){this.__base__=Control,
this.__base__(t);var e=this;function a(){var t=e.data,a=function(){var t=e.data,a=t.bitmap.width,r=t.bitmap.height;return Math.min(e.width/a,e.height/r)
}()*e.zoom;return{k:a,tx:(e.width-t.bitmap.width*a)/2+e.ox,ty:(e.height-t.bitmap.height*a)/2+e.oy}}this.data=null,this.zoom=1,this.ox=0,this.oy=0,
this.drag=null,this.setScaledMinSize(420,420),this.toolTip="<p>Mouse wheel: zoom &nbsp; Drag: pan &nbsp; Double click: fit</p>",this.onPaint=function(){
var t=new Graphics(this);if(t.fillRect(0,0,this.width,this.height,new Brush(4280295456)),!e.data)return t.pen=new Pen(4288716960),
t.drawTextRect(0,0,this.width,this.height,"Press Analyze to see the crop",TextAlign_Center|TextAlign_VertCenter),void t.end();var r=a(),n=e.data
;t.translateTransformation(r.tx,r.ty),t.scaleTransformation(r.k),t.drawBitmap(0,0,n.bitmap),t.resetTransformation(),t.antialiasing=!0,
t.pen=new Pen(4294956032,2);for(var i=0;i<4;i++){var o=n.corners[i],s=n.corners[(i+1)%4]
;t.drawLine(r.tx+r.k*o.x/n.scale,r.ty+r.k*o.y/n.scale,r.tx+r.k*s.x/n.scale,r.ty+r.k*s.y/n.scale)}t.end()},this.onMouseWheel=function(t,r,n){if(e.data){
var i=a(),o=(t-i.tx)/i.k,s=(r-i.ty)/i.k;if(e.zoom=Math.max(1,Math.min(32,e.zoom*(n>0?1.25:.8))),1===e.zoom)e.ox=e.oy=0;else{var h=a();e.ox+=t-(h.tx+o*h.k),
e.oy+=r-(h.ty+s*h.k)}e.update()}},this.onMousePress=function(t,a){e.drag={x:t,y:a,ox:e.ox,oy:e.oy}},this.onMouseMove=function(t,a){
e.drag&&(e.ox=e.drag.ox+t-e.drag.x,e.oy=e.drag.oy+a-e.drag.y,e.update())},this.onMouseRelease=function(){e.drag=null},this.onMouseDoubleClick=function(){
e.zoom=1,e.ox=e.oy=0,e.update()},this.onResize=function(){e.update()}}function _(t){
for(var e=t.keywords,a=t.mainView.image,r=0;r<e.length;r++)if("HISTORY"===e[r].name){var n=/SmartCrop [^:]*: (\d+)x(\d+) crop/.exec(e[r].comment+" "+e[r].value)
;if(n&&+n[1]===a.width&&+n[2]===a.height)return!0}return!1}function k(){this.__base__=Dialog,this.__base__();var t=this;function e(e){return function(){
Dialog.openBrowser(e),t.ok()}}this.textLabel=new Label(this),this.textLabel.wordWrapping=!0,this.textLabel.useRichText=!0,
this.textLabel.text="<p>Thank you for using SmartCrop! If it saved you time, you can support its development \u2014 any amount via PayPal, or by card with one of the buttons below.</p>",
this.textLabel.setScaledFixedWidth(380),this.paypalButton=new PushButton(this),this.paypalButton.text="PayPal (any amount)",
this.paypalButton.onClick=e("https://www.paypal.com/donate/?business=contact%40bluebelleweddings.com&no_recurring=0&item_name=SmartCrop"),
this.cardLabel=new Label(this),this.cardLabel.text="By card:",this.cardSizer=new HorizontalSizer,this.cardSizer.spacing=4;for(var a=0;a<g.length;++a){
var r=new PushButton(this);r.text="$"+g[a][0],r.onClick=e(g[a][1]),this.cardSizer.add(r,100)}this.sizer=new VerticalSizer,this.sizer.margin=12,
this.sizer.spacing=8,this.sizer.add(this.textLabel),this.sizer.add(this.paypalButton),this.sizer.addSpacing(4),this.sizer.add(this.cardLabel),
this.sizer.add(this.cardSizer),this.windowTitle="Support the author",this.adjustToContents(),this.setFixedSize()}function T(){this.__base__=Dialog,
this.__base__();var t=this;this.analysis=null;var e=this.font.width("Max rotation angle (\xb0):")+8;this.helpLabel=new Label(this),
this.helpLabel.frameStyle=FrameStyle_Box,this.helpLabel.margin=6,this.helpLabel.wordWrapping=!0,this.helpLabel.useRichText=!0,
this.helpLabel.text="<b>"+d+" v"+u+"</b> &mdash; tick the masters to crop. The script finds black borders and noisy stacking edges on each of them, builds the largest rectangle that is clean on <i>all</i> of them (at any angle, if rotating keeps more of the field) and crops every ticked image identically. Masters that are not registered to each other can be registered first (untick the box below). Every step can be undone (Ctrl+Z).",
this.tree=new TreeBox(this),this.tree.numberOfColumns=3,this.tree.headerVisible=!0,this.tree.setHeaderText(0,"Image"),this.tree.setHeaderText(1,"Size"),
this.tree.setHeaderText(2,"Channels"),this.tree.rootDecoration=!1,this.tree.alternateRowColor=!0,this.tree.setScaledMinSize(480,200)
;for(var a=ImageWindow.openWindows,r=0;r<a.length;r++)if(!a[r].isNull&&(a[r].visible||a[r].iconic)){var n=a[r].mainView
;if(!n.isNull&&0!==n.id.indexOf("SmartCrop_preview")){var i=new TreeBoxNode(this.tree);i.checkable=!0,i.checked=!0,i.setText(0,n.id),
i.setText(1,n.image.width+" x "+n.image.height),i.setText(2,n.image.isColor?"RGB":"Gray"),i.viewId=n.id}}
for(var o=0;o<3;o++)this.tree.adjustColumnWidthToContents(o);function s(a,r,n,i,o,s,h){var l=new NumericControl(t);return l.label.text=a,l.label.minWidth=e,
l.setRange(r,n),l.slider.setRange(0,Math.round((n-r)*Math.pow(10,Math.min(i,1)))),l.slider.scaledMinWidth=200,l.setPrecision(i),l.setValue(o),l.toolTip=s,
l.onValueUpdated=function(e){h(e),t.invalidate()},l}this.tree.onNodeUpdated=function(){t.invalidate()},this.allButton=new PushButton(this),
this.allButton.text="Select all",this.allButton.onClick=function(){t.setAll(!0)},this.noneButton=new PushButton(this),this.noneButton.text="Select none",
this.noneButton.onClick=function(){t.setAll(!1)},this.listButtons=new HorizontalSizer,this.listButtons.spacing=6,this.listButtons.add(this.allButton),
this.listButtons.add(this.noneButton),this.listButtons.addStretch(),this.regCheck=new CheckBox(this),
this.regCheck.text="Images are already registered to each other",this.regCheck.checked=!0,
this.regCheck.toolTip="<p>Untick for masters that were stacked separately (other software, other nights, other cameras): SmartCrop registers them first - by stars, or by their astrometric solutions when star matching fails - to the image that gives the largest common crop. Registration is an undoable step on each image.</p>",
this.regCheck.onCheck=function(){t.invalidate()
},this.noiseCtl=s("Edge noise tolerance (%):",5,200,0,w.noiseTolPct,"<p>Edges whose noise exceeds the interior noise by more than this are cut off (areas covered by fewer subframes). Lower = stricter crop.</p>",function(t){
w.noiseTolPct=t
}),this.scanCtl=s("Max edge depth (px):",20,1e3,0,w.scanPx,"<p>Noisy edges are searched for no deeper than this from the data border.</p>",function(t){
w.scanPx=Math.round(t)}),this.marginCtl=s("Extra margin (px):",0,200,0,w.extraMarginPx,"<p>Additional safety margin cut from the usable area.</p>",function(t){
w.extraMarginPx=Math.round(t)}),this.rotCheck=new CheckBox(this),this.rotCheck.text="Allow rotated crop",this.rotCheck.checked=w.allowRotation,
this.rotCheck.toolTip="<p>Rotate the crop rectangle (and the images) when this keeps noticeably more of the field.</p>",this.rotCheck.onCheck=function(e){
w.allowRotation=e,t.gainCtl.enabled=e,t.invalidate()
},this.gainCtl=s("Min area gain (%):",0,20,1,w.minGainPct,"<p>Rotate only if the rotated crop is at least this much larger than the best axis-aligned one (rotation resamples the images).</p>",function(t){
w.minGainPct=t}),this.gainCtl.enabled=w.allowRotation,this.paramBox=new GroupBox(this),this.paramBox.title="Parameters",this.paramBox.sizer=new VerticalSizer,
this.paramBox.sizer.margin=6,this.paramBox.sizer.spacing=4,this.paramBox.sizer.add(this.noiseCtl),this.paramBox.sizer.add(this.scanCtl),
this.paramBox.sizer.add(this.marginCtl),this.paramBox.sizer.add(this.rotCheck),this.paramBox.sizer.add(this.gainCtl),this.resultLabel=new Label(this),
this.resultLabel.frameStyle=FrameStyle_Sunken,this.resultLabel.margin=6,this.resultLabel.wordWrapping=!0,
this.resultLabel.text="Press Analyze to compute the crop.",this.resultLabel.setScaledMinHeight(48),this.analyzeButton=new PushButton(this),
this.analyzeButton.text="Analyze",this.analyzeButton.icon=this.scaledResource(":/icons/find.png"),this.analyzeButton.onClick=function(){t.analyze()},
this.applyButton=new PushButton(this),this.applyButton.text="Crop",this.applyButton.icon=this.scaledResource(":/icons/ok.png"),
this.applyButton.toolTip="<p>Crop all ticked images (analyzes first if needed).</p>",this.applyButton.onClick=function(){t.apply()},
this.closeButton=new PushButton(this),this.closeButton.text="Close",this.closeButton.icon=this.scaledResource(":/icons/close.png"),
this.closeButton.onClick=function(){t.cancel()},this.heartLabel=new Label(this),this.heartLabel.useRichText=!0,
this.heartLabel.text='<span style="color:#e0245e; font-size:15pt;">&#9829;</span>',
this.heartLabel.toolTip="<p>Like SmartCrop? Support its development with a donation (PayPal or card).</p>",
this.heartLabel.cursor=new Cursor(StdCursor_PointingHand),this.heartLabel.onMousePress=function(){(new k).execute()},this.buttons=new HorizontalSizer,
this.buttons.spacing=6,this.buttons.add(this.heartLabel),this.buttons.addStretch(),this.buttons.add(this.analyzeButton),this.buttons.add(this.applyButton),
this.buttons.add(this.closeButton),this.preview=new z(this),this.leftSizer=new VerticalSizer,this.leftSizer.spacing=6,this.leftSizer.add(this.helpLabel),
this.leftSizer.add(this.tree,100),this.leftSizer.add(this.listButtons),this.leftSizer.add(this.regCheck),this.leftSizer.add(this.paramBox),
this.leftSizer.add(this.resultLabel),this.leftSizer.add(this.buttons),this.sizer=new HorizontalSizer,this.sizer.margin=8,this.sizer.spacing=8,
this.sizer.add(this.leftSizer),this.sizer.add(this.preview,100),this.windowTitle=d+" v"+u,this.adjustToContents(),this.setScaledMinSize(1e3,620)}
z.prototype=new Control,z.prototype.setData=function(t){this.data=t,this.zoom=1,this.ox=this.oy=0,this.update()},k.prototype=new Dialog,T.prototype=new Dialog,
T.prototype.setAll=function(t){for(var e=0;e<this.tree.numberOfChildren;e++)this.tree.child(e).checked=t;this.invalidate()},T.prototype.invalidate=function(){
this.analysis&&(this.resultLabel.text="Parameters or selection changed - press Analyze again.",this.preview.setData(null)),this.analysis=null},
T.prototype.selectedViews=function(){for(var t=[],e=0;e<this.tree.numberOfChildren;e++){var a=this.tree.child(e);if(a.checked){var r=View.viewById(a.viewId)
;r&&!r.isNull&&t.push(r)}}return t},T.prototype.analyze=function(){var t=this.selectedViews()
;if(0===t.length)return new MessageBox("Tick at least one image.",d,StdIcon_Warning,StdButton_Ok).execute(),!1
;for(var i,o,s,f=[],g=0;g<t.length;g++)_(t[g].window)&&f.push(t[g].id)
;if(f.length>0&&new MessageBox("Already cropped by SmartCrop:\n   "+f.join("\n   ")+"\n\nAnalyze again anyway? A second pass may trim the edges a little more.",d,StdIcon_Question,StdButton_Yes,StdButton_No).execute()!==StdButton_Yes)return!1
;this.enabled=!1,console.show(),console.abortEnabled=!0;try{console.noteln("<end><cbr><br>"+d+" v"+u+": "+t.length+" image(s)");var m=Date.now()
;!this.regCheck.checked&&t.length>1&&(function(t){if(!(t.length<2)){for(var e=!0,r=0;r<t.length;r++)t[r].window.hasAstrometricSolution||(e=!1)
;var i=t[0],o=i.image.width,s=i.image.height,d=a(o,s),u=Math.ceil(o/d),f=Math.ceil(s/d)
;console.noteln("<end><cbr>Registration: estimating frame positions relative to "+i.id);var g=n(A(i.image),o,s,p()),w=new Uint8Array(u*f)
;for(r=0;r<w.length;r++)w[r]=g.outside[r]?0:1;var m=[w],v=[null],y=["reference"],M=[null];try{for(var S=1;S<t.length;S++){processEvents()
;var z=x(t[S],"SmartCrop_tmp"+S);v.push(z);var _={};if(b(z.mainView,i,_)){var k=n(A(z.mainView.image),o,s,p()),T=new Uint8Array(u*f)
;for(r=0;r<T.length;r++)T[r]=k.outside[r]?0:1;m.push(T),y.push("stars"),M.push(null===_.angle?null:[_.angle,-_.angle])}else{
if(!e)throw new Error("Could not register "+t[S].id+" to "+i.id+" by stars, and not all images are plate-solved (astrometric registration needs a solution on every image).")
;z.forceClose(),v[S]=null,m.push(P(t[S].window,i.window,u,f,d)),y.push("astrometry");var F=C(t[S].window,i.window);M.push(null===F?null:[F])}
console.writeln("   "+t[S].id+": "+y[S]+(M[S]?format(", rotation %.2f\xb0",M[S][0]):", rotation from the frame edges"))}var R=function(t,e,a,r){
for(var n=Math.max(1,Math.round(Math.max(e,a)/250)),i=new Uint8Array(e*a),o=0;o<i.length;o++){for(var s=1,d=0;d<t.length&&s;d++)t[d][o]||(s=0);i[o]=s}
var u=l(i,e,a,n),f=u.w*u.h,g=function(t,e,a){var r=Math.PI/180,n={area:-1,angleDeg:0};function i(i){var o=h(t,e,a,0===i?0:i*r);o.area>n.area&&(n={area:o.area,
angleDeg:i})}for(var o=-45;o<=45+1e-9;o+=1)i(Math.round(100*o)/100);var s=n.angleDeg
;for(o=Math.max(-45,s-1);o<=Math.min(45,s+1)+1e-9;o+=.1)i(Math.round(100*o)/100);return n}(u.g,u.w,u.h),w={index:0,cropAngle:g.angleDeg,areaFrac:g.area/f,
orientations:[],rotations:[]};for(d=0;d<t.length;d++){var m=0===d?0:c(t[d],e,a,r&&r[d]);null===m&&(m=0);var p=Math.abs(((g.angleDeg-m)%90+135)%90-45)
;w.orientations.push(m),w.rotations.push(p),p<w.rotations[w.index]-.05&&(w.index=d)}return w}(m,u,f,M)
;for(console.writeln(format("   best common crop: %.1f%% of the frame at %+.2f\xb0",100*R.areaFrac,R.cropAngle)),
S=0;S<t.length;S++)console.writeln(format("   %-28s tilt %+6.2f\xb0, needs %5.2f\xb0 of crop rotation as reference%s",t[S].id,R.orientations[S],R.rotations[S],S===R.index?"   <- chosen":""))
;var I=t[R.index];for(console.noteln("Registering to "+I.id),S=0;S<t.length;S++)if(S!==R.index){processEvents();var D=t[S],L=!1;if(0===R.index&&v[S]){
D.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{D.image.assign(v[S].mainView.image)}finally{D.endProcess()}L=!0}
if(L||"astrometry"===y[S]||(L=b(D,I)),!L&&e&&(L=B(D,I)),!L)throw new Error("Could not register "+D.id+" to "+I.id+".");console.writeln("   "+D.id+" registered")
}}finally{for(S=0;S<v.length;S++)v[S]&&!v[S].isNull&&v[S].forceClose()}}}(t),this.regCheck.checked=!0),this.analysis=function(t){
for(var a=p(),r=[],i=t[0].image.width,o=t[0].image.height,s=0;s<t.length;s++){var c=t[s].image
;if(c.width!==i||c.height!==o)throw new Error(t[s].id+" is "+c.width+"x"+c.height+", but "+t[0].id+" is "+i+"x"+o+'. The images are not registered to each other - untick "Images are already registered" to let SmartCrop register them.')
}for(s=0;s<t.length;s++){var d=Date.now();console.write("<end><cbr>Analyzing "+t[s].id+" ... "),processEvents();var u=n(A(t[s].image),i,o,a);u.id=t[s].id,
console.writeln(format("good %.1f%% (no data %.1f%%, noisy edges %.1f%%)  %.1f s",100*u.goodFrac,100*u.noDataFrac,100*u.artifactFrac,(Date.now()-d)/1e3))
;for(var f=0;f<u.notes.length;f++)console.warningln("   ** "+u.notes[f]);r.push(u),processEvents(),gc()}var g=function(t){
for(var e=t[0],a=new Uint8Array(e.bad.length),r=0;r<t.length;r++){var n=t[r];if(n.w!==e.w||n.h!==e.h)throw new Error("Images have different dimensions")
;for(var i=0;i<a.length;i++)a[i]|=n.bad[i]}return{cell:e.cell,gw:e.gw,gh:e.gh,w:e.w,h:e.h,bad:a}}(r);console.write("Searching for the best crop ... "),
processEvents();var w=function(t,a){a=e(a);for(var r=t.gw,n=t.gh,i=t.cell,o=r*n,s=new Uint8Array(o),c=0;c<o;c++)s[c]=t.bad[c]?0:1;var d=h(s,r,n,0)
;if(0===d.area)throw new Error("No usable area common to all images");var u=d.axis,f={x0:u.x0*i,y0:u.y0*i,x1:Math.min(t.w,u.x1*i),y1:Math.min(t.h,u.y1*i),
angleDeg:0,rotated:!1};if(f.width=f.x1-f.x0,f.height=f.y1-f.y0,f.cx=(f.x0+f.x1)/2,f.cy=(f.y0+f.y1)/2,f.axisAreaFrac=f.areaFrac=f.width*f.height/(t.w*t.h),
!a.allowRotation)return f;for(var g=new Uint8Array(o),w=0;w<n;w++)for(var m=0;m<r;m++){for(var p=s[w*r+m],v=-1;v<=1&&p;v++)for(var y=-1;y<=1&&p;y++){
var x=m+y,b=w+v;(x<0||b<0||x>=r||b>=n||!s[b*r+x])&&(p=0)}g[w*r+m]=p}var M=Math.PI/180,S=null;function P(t){if(!(Math.abs(t)<1e-9)){var e=h(g,r,n,t*M)
;(!S||e.area>S.area)&&(S=e)}}for(var C=Math.max(1,Math.round(Math.max(r,n)/250)),B=l(g,r,n,C),A=[],z=-45;z<45;z+=.5)A.push({deg:z,area:h(B.g,B.w,B.h,z*M).area})
;A.sort(function(t,e){return e.area-t.area});var _=[];for(c=0;c<A.length&&_.length<3;c++){for(var k=!1,T=0;T<_.length;T++)Math.abs(_[T]-A[c].deg)<2&&(k=!0)
;k||_.push(A[c].deg)}for(c=0;c<_.length;c++)for(z=_[c]-.75;z<=_[c]+.75+1e-9;z+=.05)P(Math.round(1e3*z)/1e3);if(!S)return f;var F=S.angle/M
;for(z=F-.05;z<=F+.05+1e-9;z+=.01)P(Math.round(1e3*z)/1e3);var R=S.w*i,I=S.h*i,D=R*I/(t.w*t.h);return D>=f.axisAreaFrac*(1+a.minGainPct/100)?f={cx:S.cx*i,
cy:S.cy*i,width:R,height:I,angleDeg:S.angle/M,rotated:!0,areaFrac:D,axisAreaFrac:f.axisAreaFrac}:(f.bestRotatedFrac=D,f.bestRotatedDeg=S.angle/M),f}(g,a)
;console.writeln("done");var m=function(t,e){for(var a=e.rotated?[1,-1]:[1],r=0;r<a.length;r++){var n=y(t);n.interpolation=Interpolation_Bilinear,
v(n,e,a[r],[1]);var i=n.maximum()<.5&&n.width===Math.floor(e.width)&&n.height===Math.floor(e.height);if(n.free(),i)return a[r]}return 0}(g,w)
;if(0===m)throw new Error("Internal check failed: the computed crop would include bad pixels. Nothing was changed.");w.sign=m;var x=r[0]
;for(s=1;s<r.length;s++)r[s].goodFrac<x.goodFrac&&(x=r[s]);return{list:r,comb:g,plan:w,worst:x}}(t),this.analysis.ids=t.map(function(t){return t.id}).join("|")
;var M=(o=(i=this.analysis).plan,s=format("%d x %d px",Math.floor(o.width),Math.floor(o.height)),
o.rotated?s+=format(", frame tilted %.2f\xb0 %s",Math.abs(o.angleDeg),o.angleDeg>0?"clockwise":"counter-clockwise"):s+=", no rotation",
s+=format(", keeps %.1f%% of the frame",100*o.areaFrac),
o.rotated?s+=format(" (axis-aligned: %.1f%%)",100*o.axisAreaFrac):void 0!==o.bestRotatedFrac&&w.allowRotation&&(s+=format(" (rotation would give only %.1f%%)",100*o.bestRotatedFrac)),
s+"\nMost limiting image: "+i.worst.id+format(" (%.1f%% usable)",100*i.worst.goodFrac));console.noteln(M),
console.writeln(format("Analysis time %.1f s",(Date.now()-m)/1e3)),this.resultLabel.text=M;var S=function(t,e){
for(var a=t.comb,n=a.w,i=a.h,o=a.cell,s=e[0],h=0;h<e.length;h++)e[h].id===t.worst.id&&(s=e[h])
;for(var l=Math.max(1,Math.ceil(Math.max(n,i)/1400)),c=Math.floor(n/l),d=Math.floor(i/l),u=c*d,f=A(s.image),g=f.length,w=new Float32Array(u),m=0;m<d;m++)for(var p=0;p<c;p++){
for(var v=0,y=0;y<l;y++)for(var x=(m*l+y)*n+p*l,b=0;b<l;b++)for(var M=0;M<g;M++)v+=f[M][x+b];w[m*c+p]=v/(l*l*g)}f=null;var S=[]
;for(h=0;h<u;h+=7)w[h]>0&&S.push(w[h]);var P=r(S),C=1.4826*r(S.map(function(t){return Math.abs(t-P)})),B=Math.max(0,P-2.8*C),z=Math.max(1e-6,1-B)
;function _(t,e){return e<=0?0:e>=1?1:(t-1)*e/((2*t-1)*e-t)}var k=_(.25,(P-B)/z),T=new Float32Array(u),F=new Float32Array(u),R=new Float32Array(u)
;for(m=0;m<d;m++){var I=Math.floor((m*l+l/2)/o)*a.gw;for(p=0;p<c;p++){var D=_(k,(w[h=m*c+p]-B)/z);a.bad[I+Math.floor((p*l+l/2)/o)]?(T[h]=.35+.5*D,F[h]=.4*D,
R[h]=.4*D):T[h]=F[h]=R[h]=D}}var L=new Image(c,d,3,ColorSpace_RGB);L.setSamples(T,new Rect(0,0,c,d),0),L.setSamples(F,new Rect(0,0,c,d),1),
L.setSamples(R,new Rect(0,0,c,d),2);var U=L.render();return L.free(),{bitmap:U,scale:l}}(this.analysis,t);return S.corners=function(t){
var e=t.angleDeg*Math.PI/180,a=Math.cos(e),r=Math.sin(e),n=t.width/2,i=t.height/2;return[[-n,-i],[n,-i],[n,i],[-n,i]].map(function(e){return{
x:t.cx+e[0]*a-e[1]*r,y:t.cy+e[0]*r+e[1]*a}})}(this.analysis.plan),this.preview.setData(S),!0}catch(t){return this.analysis=null,
console.criticalln(t.toString()),this.resultLabel.text="Error: "+t.toString(),new MessageBox(t.toString(),d,StdIcon_Error,StdButton_Ok).execute(),!1}finally{
console.abortEnabled=!1,this.enabled=!0}},T.prototype.apply=function(){var t=this.selectedViews(),e=t.map(function(t){return t.id}).join("|")
;if(this.analysis&&this.analysis.ids===e||this.analyze()){this.enabled=!1;try{!function(t,e){for(var a=e.plan,r=0;r<t.length;r++){var n=t[r],i=n.window
;console.writeln("Cropping "+n.id),processEvents();for(var o=n.image.numberOfChannels,s=[],h=0;h<o;h++)s.push(0);var l=i.hasAstrometricSolution
;n.beginProcess(UndoFlag_PixelData|UndoFlag_Keywords|UndoFlag_AstrometricSolution);try{n.image.interpolation=Interpolation_Lanczos3,v(n.image,a,a.sign,s)
;var c=i.keywords
;c.push(new FITSKeyword("HISTORY","",format("SmartCrop %s: %dx%d crop, angle %.3f deg",u,Math.floor(a.width),Math.floor(a.height),a.rotated?a.angleDeg:0))),
i.keywords=c,l&&i.clearAstrometricSolution()}finally{n.endProcess()}
l&&console.warningln("   ** astrometric solution removed (geometry changed) - re-solve the image if needed")}}(t,this.analysis),
console.noteln("<end><cbr>"+d+": "+t.length+" image(s) cropped."),m(),this.ok()}catch(t){console.criticalln(t.toString()),
new MessageBox(t.toString(),d,StdIcon_Error,StdButton_Ok).execute(),this.enabled=!0}}},console.hide(),0!==ImageWindow.openWindows.length?(function(){
function t(t,e,a){var r=Settings.read(f+"/"+t,e);return Settings.lastReadOK?r:a}w.noiseTolPct=t("noiseTolPct",DataType_Double,w.noiseTolPct),
w.scanPx=t("scanPx",DataType_Int32,w.scanPx),w.extraMarginPx=t("extraMarginPx",DataType_Int32,w.extraMarginPx),
w.allowRotation=t("allowRotation",DataType_Boolean,w.allowRotation),w.minGainPct=t("minGainPct",DataType_Double,w.minGainPct)}(),(new T).execute(),
m()):new MessageBox("Open the registered master frames first.",d,StdIcon_Information,StdButton_Ok).execute()}();
