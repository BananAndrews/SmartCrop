// SmartCrop 1.0.2 for PixInsight - Copyright (c) 2026 BananAndrews. All rights reserved.
// Free to use. Modification, reverse engineering and redistribution of modified versions are not permitted.
#feature-id    SmartCrop : Utilities > SmartCrop
#feature-info  Synchronized automatic crop of registered master frames.<br/>\
   Detects black borders and noisy stacking edges on every selected image, \
   finds the largest (optionally rotated) rectangle with good data on all of \
   them and crops all images identically.
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdCursor.jsh>
!function(){var t={zeroLevel:0,noiseTol:.3,darkTolSigma:0,scanPx:300,voteRadius:5,extraMarginPx:0,allowRotation:!0,maxAngleDeg:10,minGainPct:2};function e(e){
var a={};for(var r in t)a[r]=t[r];if(e)for(var n in e)a[n]=e[n];return a}function a(t,e){if(void 0===e&&(e=t.length),0===e)return NaN
;var a=Array.prototype.slice.call(t,0,e).sort(function(t,e){return t-e});return 1&e?a[e>>1]:.5*(a[(e>>1)-1]+a[e>>1])}function r(t,r,i,o){o=e(o)
;for(var s=function(t,e){return Math.max(2,Math.round(Math.max(t,e)/1e3))
}(r,i),l=Math.ceil(r/s),h=Math.ceil(i/s),c=l*h,d=t.length,f=new Uint8Array(c),u=new Float32Array(c),g=new Float32Array(c),p=new Float32Array(r),w=new Uint8Array(r),m=new Float64Array(l),x=new Float64Array(l),v=new Int32Array(l),y=new Int32Array(l),b=0;b<h;b++){
for(var M=0;M<l;M++)m[M]=0,x[M]=0,v[M]=0,y[M]=0;for(var P=Math.min(i,(b+1)*s),B=b*s;B<P;B++){for(var A=B*r,C=0;C<r;C++){for(var S=0,T=0,k=0;k<d;k++){
var D=t[k][A+C];D>o.zeroLevel||(T=1),S+=D}p[C]=S/d,w[C]=T}for(M=0;M<l;M++){var z=M*s,_=Math.min(r,z+s),F=b*l+M;for(C=z;C<_;C++)w[C]&&(f[F]=1),m[M]+=p[C],v[M]++,
C+1<_&&(x[M]+=Math.abs(p[C+1]-p[C]),y[M]++)}}for(M=0;M<l;M++)u[F=b*l+M]=m[M]/Math.max(1,v[M]),g[F]=x[M]/Math.max(1,y[M])}
var R=new Uint8Array(c),I=new Int32Array(c),L=0,E=0;function G(t){f[t]&&!R[t]&&(R[t]=1,I[E++]=t)}for(M=0;M<l;M++)G(M),G((h-1)*l+M);for(b=0;b<h;b++)G(b*l),
G(b*l+l-1);for(;L<E;)for(var U=((H=I[L++])-(ut=H%l))/l,V=-1;V<=1;V++)for(var N=-1;N<=1;N++){var O=U+V;(gt=ut+N)>=0&&O>=0&&gt<l&&O<h&&G(O*l+gt)}
for(var W=new Float32Array(c),H=0;H<c;H++)W[H]=R[H]?0:1e9;function j(t,e){return t<0||e<0||t>=l||e>=h?0:W[e*l+t]}
for(B=0;B<h;B++)for(C=0;C<l;C++)0!==W[H=B*l+C]&&(W[H]=Math.min(W[H],j(C-1,B)+3,j(C,B-1)+3,j(C-1,B-1)+4,j(C+1,B-1)+4))
;for(B=h-1;B>=0;B--)for(C=l-1;C>=0;C--)0!==W[H=B*l+C]&&(W[H]=Math.min(W[H],j(C+1,B)+3,j(C,B+1)+3,j(C+1,B+1)+4,j(C-1,B+1)+4));var K=new Int32Array(c)
;for(H=0;H<c;H++)K[H]=R[H]?0:Math.max(1,Math.round(W[H]/3))
;var Y=Math.max(4,Math.round(o.scanPx/s)),Z=n(u,K,l,h,Y),q=n(g,K,l,h,Y),J=a(Array.prototype.filter.call(q,function(t,e){return!R[e]})),Q=new Uint8Array(c)
;for(H=0;H<c;H++)if(!(R[H]||K[H]>Y+o.voteRadius)){var X=Math.max(q[H],.25*J),$=X/1.128
;(g[H]>(1+o.noiseTol)*X||o.darkTolSigma>0&&u[H]<Z[H]-o.darkTolSigma*$)&&(Q[H]=1)}var tt=o.voteRadius,et=l+1,at=new Int32Array(et*(h+1));for(B=0;B<h;B++){
var rt=0;for(C=0;C<l;C++)rt+=Q[H=B*l+C]||R[H]?1:0,at[(B+1)*et+C+1]=at[B*et+C+1]+rt}var nt=new Uint8Array(c)
;for(B=0;B<h;B++)for(C=0;C<l;C++)if(!(R[H=B*l+C]||K[H]>Y)){
var it=Math.max(0,C-tt),ot=Math.min(l,C+tt+1),st=Math.max(0,B-tt),lt=Math.min(h,B+tt+1),ht=at[lt*et+ot]-at[st*et+ot]-at[lt*et+it]+at[st*et+it],ct=(2*tt+1)*(2*tt+1)
;2*(ht+=ct-(ot-it)*(lt-st))>ct&&(nt[H]=1)}var dt=new Uint8Array(c);for(L=E=0,H=0;H<c;H++)R[H]&&(dt[H]=1,I[E++]=H);function ft(t){nt[t]&&!dt[t]&&(dt[t]=1,
I[E++]=t)}for(M=0;M<l;M++)ft(M),ft((h-1)*l+M);for(b=0;b<h;b++)ft(b*l),ft(b*l+l-1);for(;L<E;){var ut;for(U=((H=I[L++])-(ut=H%l))/l,
V=-1;V<=1;V++)for(N=-1;N<=1;N++){var gt;O=U+V,(gt=ut+N)>=0&&O>=0&&gt<l&&O<h&&ft(O*l+gt)}}var pt=Math.ceil(o.extraMarginPx/s),wt=0,mt=0,xt=[]
;for(H=0;H<c;H++)dt[H]&&!R[H]&&mt++,!dt[H]&&pt>0&&K[H]<=pt&&(dt[H]=1),dt[H]||wt++;var vt=0;for(H=0;H<c;H++)vt+=R[H];var yt=0
;for(H=0;H<c;H++)dt[H]&&!R[H]&&K[H]>=Y&&yt++;return yt>0&&xt.push("edge artifacts reach the "+o.scanPx+" px scan limit"),{cell:s,gw:l,gh:h,w:r,h:i,bad:dt,
goodFrac:wt/c,noDataFrac:vt/c,artifactFrac:mt/c,noiseRef:J,notes:xt}}function n(t,e,r,n,o){
for(var s=Math.max(8,Math.round(Math.max(r,n)/24)),l=[],h=0;h<n;h+=s)for(var c=0;c<r;c+=s){
for(var d=[],f=h;f<Math.min(n,h+s);f++)for(var u=c;u<Math.min(r,c+s);u++)e[A=f*r+u]>o&&d.push(t[A]);d.length>=s*s/2&&l.push({x:2*(c+s/2)/r-1,y:2*(h+s/2)/n-1,
v:a(d)})}function g(t,e){return[1,t,e,t*t,t*e,e*e]}for(var p=null,w=l,m=0;m<4&&!(w.length<10);m++){
for(var x=[],v=[0,0,0,0,0,0],y=0;y<6;y++)x.push([0,0,0,0,0,0]);w.forEach(function(t){for(var e=g(t.x,t.y),a=0;a<6;a++){v[a]+=e[a]*t.v
;for(var r=0;r<6;r++)x[a][r]+=e[a]*e[r]}}),p=i(x,v);var b=l.map(function(t){for(var e=g(t.x,t.y),a=0,r=0;r<6;r++)a+=p[r]*e[r];return t.v-a
}),M=1.4826*a(b.map(Math.abs))+1e-30;w=l.filter(function(t,e){return Math.abs(b[e])<3*M})}var P=new Float32Array(r*n);if(!p){
for(var B=a(l.length?l.map(function(t){return t.v}):[0]),A=0;A<P.length;A++)P[A]=B;return P}for(f=0;f<n;f++)for(u=0;u<r;u++){
var C=g(2*(u+.5)/r-1,2*(f+.5)/n-1),S=0;for(y=0;y<6;y++)S+=p[y]*C[y];P[f*r+u]=S}return P}function i(t,e){for(var a=e.length,r=t.map(function(t,a){
return t.concat([e[a]])}),n=0;n<a;n++){for(var i=n,o=n+1;o<a;o++)Math.abs(r[o][n])>Math.abs(r[i][n])&&(i=o);var s=r[n];if(r[n]=r[i],r[i]=s,
!(Math.abs(r[n][n])<1e-300))for(o=n+1;o<a;o++)for(var l=r[o][n]/r[n][n],h=n;h<=a;h++)r[o][h]-=l*r[n][h]}var c=[];for(o=0;o<a;o++)c.push(0);for(o=a-1;o>=0;o--){
var d=r[o][a];for(h=o+1;h<a;h++)d-=r[o][h]*c[h];c[o]=Math.abs(r[o][o])<1e-300?0:d/r[o][o]}return c}function o(t,e,a){
for(var r=new Int32Array(e),n=new Int32Array(e+1),i={area:0,x0:0,y0:0,x1:0,y1:0},o=0;o<a;o++){for(var s=o*e,l=0;l<e;l++)r[l]=t[s+l]?r[l]+1:0;var h=0
;for(l=0;l<=e;l++){for(var c=l<e?r[l]:0;h>0&&r[n[h-1]]>=c;){var d=r[n[--h]],f=h>0?n[h-1]+1:0,u=d*(l-f);u>i.area&&(i={area:u,x0:f,y0:o-d+1,x1:l,y1:o+1})}n[h++]=l
}}return i}function s(t,e,a,r){if(0===r)return{area:(x=o(t,e,a)).area,cx:(x.x0+x.x1)/2,cy:(x.y0+x.y1)/2,w:x.x1-x.x0,h:x.y1-x.y0,angle:0,axis:x}
;for(var n=Math.cos(r),i=Math.sin(r),s=Math.ceil(e*Math.abs(n)+a*Math.abs(i)),l=Math.ceil(e*Math.abs(i)+a*Math.abs(n)),h=new Uint8Array(s*l),c=e/2,d=a/2,f=0;f<l;f++)for(var u=f+.5-l/2,g=0;g<s;g++){
var p=g+.5-s/2,w=Math.floor(c+p*n-u*i),m=Math.floor(d+p*i+u*n);w>=0&&m>=0&&w<e&&m<a&&(h[f*s+g]=t[m*e+w])}var x;return p=((x=o(h,s,l)).x0+x.x1)/2-s/2,
u=(x.y0+x.y1)/2-l/2,{area:x.area,cx:c+p*n-u*i,cy:d+p*i+u*n,w:x.x1-x.x0,h:x.y1-x.y0,angle:r}}var l="SmartCrop",h="1.0.2",c="SmartCrop",d={noiseTolPct:30,
scanPx:300,extraMarginPx:0,allowRotation:!0,maxAngleDeg:10,minGainPct:2,createPreview:!1};function f(){
Settings.write(c+"/noiseTolPct",DataType_Double,d.noiseTolPct),Settings.write(c+"/scanPx",DataType_Int32,d.scanPx),
Settings.write(c+"/extraMarginPx",DataType_Int32,d.extraMarginPx),Settings.write(c+"/allowRotation",DataType_Boolean,d.allowRotation),
Settings.write(c+"/maxAngleDeg",DataType_Double,d.maxAngleDeg),Settings.write(c+"/minGainPct",DataType_Double,d.minGainPct),
Settings.write(c+"/createPreview",DataType_Boolean,d.createPreview)}function u(t,e,a,r){if(e.rotated){
var n=e.angleDeg*Math.PI/180,i=Math.abs(Math.cos(n)),o=Math.abs(Math.sin(n)),s=Math.floor(e.width),l=Math.floor(e.height),h=Math.max(s/2,s/2*i+l/2*o),c=Math.max(l/2,s/2*o+l/2*i),d=Math.floor(e.cx-h-8),f=Math.floor(e.cy-c-8),u=Math.ceil(e.cx+h+8),g=Math.ceil(e.cy+c+8)
;t.cropTo(d,f,u,g,r);var p=e.cx-d,w=e.cy-f;t.rotate(a*n,p,w,r);var m=Math.round(p-s/2),x=Math.round(w-l/2);t.cropTo(m,x,m+s,x+l,r)
}else t.cropTo(e.x0,e.y0,e.x1,e.y1,r)}function g(t){
for(var e=t.w,a=t.h,r=t.cell,n=new Float32Array(e*a),i=0;i<a;i++)for(var o=Math.floor(i/r)*t.gw,s=i*e,l=0;l<e;l++)n[s+l]=t.bad[o+Math.floor(l/r)]
;return new Image(n,e,a,1,ColorSpace.Gray)}function p(t){for(var e=[],a=0;a<t.numberOfChannels;a++)e.push(t.toFloat32Array(new Rect(0,0,t.width,t.height),a))
;return e}function w(){this.__base__=Dialog,this.__base__();var t=this;this.analysis=null;var e=this.font.width("Max rotation angle (\xb0):")+8
;this.helpLabel=new Label(this),this.helpLabel.frameStyle=FrameStyle_Box,this.helpLabel.margin=6,this.helpLabel.wordWrapping=!0,this.helpLabel.useRichText=!0,
this.helpLabel.text="<b>"+l+" v"+h+"</b> &mdash; tick the registered masters to crop. The script finds black borders and noisy stacking edges on each of them, builds the largest rectangle that is clean on <i>all</i> of them (rotated if that keeps more of the field) and crops every ticked image identically. Each crop can be undone (Ctrl+Z).",
this.tree=new TreeBox(this),this.tree.numberOfColumns=3,this.tree.headerVisible=!0,this.tree.setHeaderText(0,"Image"),this.tree.setHeaderText(1,"Size"),
this.tree.setHeaderText(2,"Channels"),this.tree.rootDecoration=!1,this.tree.alternateRowColor=!0,this.tree.setScaledMinSize(480,200)
;for(var a=ImageWindow.openWindows,r=0;r<a.length;r++)if(!a[r].isNull&&(a[r].visible||a[r].iconic)){var n=a[r].mainView;if(!n.isNull){
var i=new TreeBoxNode(this.tree);i.checkable=!0,i.checked=!0,i.setText(0,n.id),i.setText(1,n.image.width+" x "+n.image.height),
i.setText(2,n.image.isColor?"RGB":"Gray"),i.viewId=n.id}}for(var o=0;o<3;o++)this.tree.adjustColumnWidthToContents(o);function s(a,r,n,i,o,s,l){
var h=new NumericControl(t);return h.label.text=a,h.label.minWidth=e,h.setRange(r,n),h.slider.setRange(0,Math.round((n-r)*Math.pow(10,Math.min(i,1)))),
h.slider.scaledMinWidth=200,h.setPrecision(i),h.setValue(o),h.toolTip=s,h.onValueUpdated=function(e){l(e),t.invalidate()},h}this.tree.onNodeUpdated=function(){
t.invalidate()},this.allButton=new PushButton(this),this.allButton.text="Select all",this.allButton.onClick=function(){t.setAll(!0)},
this.noneButton=new PushButton(this),this.noneButton.text="Select none",this.noneButton.onClick=function(){t.setAll(!1)},this.listButtons=new HorizontalSizer,
this.listButtons.spacing=6,this.listButtons.add(this.allButton),this.listButtons.add(this.noneButton),this.listButtons.addStretch(),
this.noiseCtl=s("Edge noise tolerance (%):",5,200,0,d.noiseTolPct,"<p>Edges whose noise exceeds the interior noise by more than this are cut off (areas covered by fewer subframes). Lower = stricter crop.</p>",function(t){
d.noiseTolPct=t
}),this.scanCtl=s("Max edge depth (px):",20,1e3,0,d.scanPx,"<p>Noisy edges are searched for no deeper than this from the data border.</p>",function(t){
d.scanPx=Math.round(t)}),this.marginCtl=s("Extra margin (px):",0,200,0,d.extraMarginPx,"<p>Additional safety margin cut from the usable area.</p>",function(t){
d.extraMarginPx=Math.round(t)}),this.rotCheck=new CheckBox(this),this.rotCheck.text="Allow rotated crop",this.rotCheck.checked=d.allowRotation,
this.rotCheck.toolTip="<p>Rotate the crop rectangle (and the images) when this keeps noticeably more of the field.</p>",this.rotCheck.onCheck=function(e){
d.allowRotation=e,t.angleCtl.enabled=t.gainCtl.enabled=e,t.invalidate()
},this.angleCtl=s("Max rotation angle (\xb0):",.5,45,1,d.maxAngleDeg,"<p>Largest rotation tried for the crop rectangle.</p>",function(t){d.maxAngleDeg=t}),
this.gainCtl=s("Min area gain (%):",0,20,1,d.minGainPct,"<p>Rotate only if the rotated crop is at least this much larger than the best axis-aligned one (rotation resamples the images).</p>",function(t){
d.minGainPct=t}),this.angleCtl.enabled=this.gainCtl.enabled=d.allowRotation,this.previewCheck=new CheckBox(this),
this.previewCheck.text="Show analysis preview image",this.previewCheck.checked=d.createPreview,
this.previewCheck.toolTip="<p>After analysis, open an image with the unusable area (dark) and the crop outline.</p>",this.previewCheck.onCheck=function(t){
d.createPreview=t},this.paramBox=new GroupBox(this),this.paramBox.title="Parameters",this.paramBox.sizer=new VerticalSizer,this.paramBox.sizer.margin=6,
this.paramBox.sizer.spacing=4,this.paramBox.sizer.add(this.noiseCtl),this.paramBox.sizer.add(this.scanCtl),this.paramBox.sizer.add(this.marginCtl),
this.paramBox.sizer.add(this.rotCheck),this.paramBox.sizer.add(this.angleCtl),this.paramBox.sizer.add(this.gainCtl),this.paramBox.sizer.add(this.previewCheck),
this.resultLabel=new Label(this),this.resultLabel.frameStyle=FrameStyle_Sunken,this.resultLabel.margin=6,this.resultLabel.wordWrapping=!0,
this.resultLabel.text="Press Analyze to compute the crop.",this.resultLabel.setScaledMinHeight(48),this.analyzeButton=new PushButton(this),
this.analyzeButton.text="Analyze",this.analyzeButton.icon=this.scaledResource(":/icons/find.png"),this.analyzeButton.onClick=function(){t.analyze()},
this.applyButton=new PushButton(this),this.applyButton.text="Crop",this.applyButton.icon=this.scaledResource(":/icons/ok.png"),
this.applyButton.toolTip="<p>Crop all ticked images (analyzes first if needed).</p>",this.applyButton.onClick=function(){t.apply()},
this.closeButton=new PushButton(this),this.closeButton.text="Close",this.closeButton.icon=this.scaledResource(":/icons/close.png"),
this.closeButton.onClick=function(){t.cancel()},this.heartLabel=new Label(this),this.heartLabel.useRichText=!0,
this.heartLabel.text='<span style="color:#e0245e; font-size:15pt;">&#9829;</span>',
this.heartLabel.toolTip="<p>Like SmartCrop? Support its development with a donation (PayPal).</p>",this.heartLabel.cursor=new Cursor(StdCursor_PointingHand),
this.heartLabel.onMousePress=function(){
Dialog.openBrowser("https://www.paypal.com/donate/?business=contact%40bluebelleweddings.com&no_recurring=0&item_name=SmartCrop")},
this.buttons=new HorizontalSizer,this.buttons.spacing=6,this.buttons.add(this.heartLabel),this.buttons.addStretch(),this.buttons.add(this.analyzeButton),
this.buttons.add(this.applyButton),this.buttons.add(this.closeButton),this.sizer=new VerticalSizer,this.sizer.margin=8,this.sizer.spacing=6,
this.sizer.add(this.helpLabel),this.sizer.add(this.tree,100),this.sizer.add(this.listButtons),this.sizer.add(this.paramBox),this.sizer.add(this.resultLabel),
this.sizer.add(this.buttons),this.windowTitle=l+" v"+h,this.adjustToContents(),this.setScaledMinWidth(560)}w.prototype=new Dialog,
w.prototype.setAll=function(t){for(var e=0;e<this.tree.numberOfChildren;e++)this.tree.child(e).checked=t;this.invalidate()},w.prototype.invalidate=function(){
this.analysis&&(this.resultLabel.text="Parameters or selection changed - press Analyze again."),this.analysis=null},w.prototype.selectedViews=function(){
for(var t=[],e=0;e<this.tree.numberOfChildren;e++){var a=this.tree.child(e);if(a.checked){var r=View.viewById(a.viewId);r&&!r.isNull&&t.push(r)}}return t},
w.prototype.analyze=function(){var t,a,n,i=this.selectedViews()
;if(0===i.length)return new MessageBox("Tick at least one image.",l,StdIcon_Warning,StdButton_Ok).execute(),!1;this.enabled=!1,console.show(),
console.abortEnabled=!0;try{console.noteln("<end><cbr><br>"+l+" v"+h+": "+i.length+" image(s)");var o=Date.now();this.analysis=function(t){for(var a={
noiseTol:d.noiseTolPct/100,scanPx:d.scanPx,extraMarginPx:d.extraMarginPx,allowRotation:d.allowRotation,maxAngleDeg:d.maxAngleDeg,minGainPct:d.minGainPct
},n=[],i=t[0].image.width,o=t[0].image.height,l=0;l<t.length;l++){var h=t[l].image
;if(h.width!==i||h.height!==o)throw new Error(t[l].id+" is "+h.width+"x"+h.height+", but "+t[0].id+" is "+i+"x"+o+". All images must be registered to the same frame.")
}for(l=0;l<t.length;l++){var c=Date.now();console.write("<end><cbr>Analyzing "+t[l].id+" ... "),processEvents();var f=r(p(t[l].image),i,o,a);f.id=t[l].id,
console.writeln(format("good %.1f%% (no data %.1f%%, noisy edges %.1f%%)  %.1f s",100*f.goodFrac,100*f.noDataFrac,100*f.artifactFrac,(Date.now()-c)/1e3))
;for(var w=0;w<f.notes.length;w++)console.warningln("   ** "+f.notes[w]);n.push(f),processEvents(),gc()}var m=function(t){
for(var e=t[0],a=new Uint8Array(e.bad.length),r=0;r<t.length;r++){var n=t[r];if(n.w!==e.w||n.h!==e.h)throw new Error("Images have different dimensions")
;for(var i=0;i<a.length;i++)a[i]|=n.bad[i]}return{cell:e.cell,gw:e.gw,gh:e.gh,w:e.w,h:e.h,bad:a}}(n);console.write("Searching for the best crop ... "),
processEvents();var x=function(t,a){a=e(a);for(var r=t.gw,n=t.gh,i=t.cell,o=r*n,l=new Uint8Array(o),h=0;h<o;h++)l[h]=t.bad[h]?0:1;var c=s(l,r,n,0)
;if(0===c.area)throw new Error("No usable area common to all images");var d=c.axis,f={x0:d.x0*i,y0:d.y0*i,x1:Math.min(t.w,d.x1*i),y1:Math.min(t.h,d.y1*i),
angleDeg:0,rotated:!1};if(f.width=f.x1-f.x0,f.height=f.y1-f.y0,f.cx=(f.x0+f.x1)/2,f.cy=(f.y0+f.y1)/2,f.axisAreaFrac=f.areaFrac=f.width*f.height/(t.w*t.h),
!a.allowRotation||a.maxAngleDeg<=0)return f;for(var u=new Uint8Array(o),g=0;g<n;g++)for(var p=0;p<r;p++){
for(var w=l[g*r+p],m=-1;m<=1&&w;m++)for(var x=-1;x<=1&&w;x++){var v=p+x,y=g+m;(v<0||y<0||v>=r||y>=n||!l[y*r+v])&&(w=0)}u[g*r+p]=w}var b=Math.PI/180,M=null
;function P(t){if(0!==t){var e=s(u,r,n,t*b);(!M||e.area>M.area)&&(M=e)}}for(var B=.25,A=-a.maxAngleDeg;A<=a.maxAngleDeg+1e-9;A+=B)P(Math.round(1e3*A)/1e3)
;if(!M)return f;var C=M.angle/b;for(A=C-B;A<=C+B+1e-9;A+=.02)P(Math.round(1e3*A)/1e3);var S=M.w*i,T=M.h*i,k=S*T/(t.w*t.h)
;return k>=f.axisAreaFrac*(1+a.minGainPct/100)?f={cx:M.cx*i,cy:M.cy*i,width:S,height:T,angleDeg:M.angle/b,rotated:!0,areaFrac:k,axisAreaFrac:f.axisAreaFrac
}:(f.bestRotatedFrac=k,f.bestRotatedDeg=M.angle/b),f}(m,a);console.writeln("done");var v=function(t,e){for(var a=e.rotated?[1,-1]:[1],r=0;r<a.length;r++){
var n=g(t);n.interpolation=InterpolationAlgorithm.Bilinear,u(n,e,a[r],[1]);var i=n.maximum()<.5&&n.width===Math.floor(e.width)&&n.height===Math.floor(e.height)
;if(n.free(),i)return a[r]}return 0}(m,x);if(0===v)throw new Error("Internal check failed: the computed crop would include bad pixels. Nothing was changed.")
;x.sign=v;var y=n[0];for(l=1;l<n.length;l++)n[l].goodFrac<y.goodFrac&&(y=n[l]);return{list:n,comb:m,plan:x,worst:y}}(i),this.analysis.ids=i.map(function(t){
return t.id}).join("|");var c=(a=(t=this.analysis).plan,n=format("%d x %d px",Math.floor(a.width),Math.floor(a.height)),
a.rotated?n+=format(", frame tilted %.2f\xb0 %s",Math.abs(a.angleDeg),a.angleDeg>0?"clockwise":"counter-clockwise"):n+=", no rotation",
n+=format(", keeps %.1f%% of the frame",100*a.areaFrac),
a.rotated?n+=format(" (axis-aligned: %.1f%%)",100*a.axisAreaFrac):void 0!==a.bestRotatedFrac&&d.allowRotation&&(n+=format(" (rotation would give only %.1f%%)",100*a.bestRotatedFrac)),
n+"\nMost limiting image: "+t.worst.id+format(" (%.1f%% usable)",100*t.worst.goodFrac));return console.noteln(c),
console.writeln(format("Analysis time %.1f s",(Date.now()-o)/1e3)),this.resultLabel.text=c,d.createPreview&&function(t){
for(var e=t.comb,a=t.plan,r=g(e),n=e.w,i=e.h,o=r.toFloat32Array(),s=0;s<o.length;s++)o[s]=o[s]?.15:.6
;for(var l=a.angleDeg*Math.PI/180,h=Math.cos(l),c=Math.sin(l),d=a.width,f=a.height,u=4*(d+f),p=0;p<=1;p+=1/u)for(var w=[[(p-.5)*d,-f/2],[(p-.5)*d,f/2],[-d/2,(p-.5)*f],[d/2,(p-.5)*f]],m=0;m<4;m++)for(var x=w[m][0],v=w[m][1],y=-3;y<=3;y++){
var b=Math.round(a.cx+x*h-v*c+(m>=2?y:0)),M=Math.round(a.cy+x*c+v*h+(m<2?y:0));b>=0&&M>=0&&b<n&&M<i&&(o[M*n+b]=1)}
var P=new ImageWindow(n,i,1,32,!0,!1,"SmartCrop_preview");P.mainView.beginProcess(UndoFlag_NoSwapFile),P.mainView.image.setSamples(o,new Rect(0,0,n,i),0),
P.mainView.endProcess(),r.free(),P.show(),P.zoomToFit()}(this.analysis),!0}catch(t){return this.analysis=null,console.criticalln(t.toString()),
this.resultLabel.text="Error: "+t.toString(),new MessageBox(t.toString(),l,StdIcon_Error,StdButton_Ok).execute(),!1}finally{console.abortEnabled=!1,
this.enabled=!0}},w.prototype.apply=function(){var t=this.selectedViews(),e=t.map(function(t){return t.id}).join("|")
;if(this.analysis&&this.analysis.ids===e||this.analyze()){this.enabled=!1;try{!function(t,e){for(var a=e.plan,r=0;r<t.length;r++){var n=t[r],i=n.window
;console.writeln("Cropping "+n.id),processEvents();for(var o=n.image.numberOfChannels,s=[],l=0;l<o;l++)s.push(0);var c=i.hasAstrometricSolution
;n.beginProcess(UndoFlag_DefaultMode);try{n.image.interpolation=InterpolationAlgorithm.Lanczos3,n.image.interpolationClamping=.3,u(n.image,a,a.sign,s)}finally{
n.endProcess()}var d=i.keywords
;d.push(new FITSKeyword("HISTORY","",format("SmartCrop %s: %dx%d crop, angle %.3f deg",h,Math.floor(a.width),Math.floor(a.height),a.rotated?a.angleDeg:0))),
i.keywords=d,c&&(i.clearAstrometricSolution(),console.warningln("   ** astrometric solution removed (geometry changed) - re-solve the image if needed"))}
}(t,this.analysis),console.noteln("<end><cbr>"+l+": "+t.length+" image(s) cropped."),f(),this.ok()}catch(t){console.criticalln(t.toString()),
new MessageBox(t.toString(),l,StdIcon_Error,StdButton_Ok).execute(),this.enabled=!0}}},console.hide(),0!==ImageWindow.openWindows.length?(function(){
function t(t,e,a){var r=Settings.read(c+"/"+t,e);return Settings.lastReadOK?r:a}d.noiseTolPct=t("noiseTolPct",DataType_Double,d.noiseTolPct),
d.scanPx=t("scanPx",DataType_Int32,d.scanPx),d.extraMarginPx=t("extraMarginPx",DataType_Int32,d.extraMarginPx),
d.allowRotation=t("allowRotation",DataType_Boolean,d.allowRotation),d.maxAngleDeg=t("maxAngleDeg",DataType_Double,d.maxAngleDeg),
d.minGainPct=t("minGainPct",DataType_Double,d.minGainPct),d.createPreview=t("createPreview",DataType_Boolean,d.createPreview)}(),(new w).execute(),
f()):new MessageBox("Open the registered master frames first.",l,StdIcon_Information,StdButton_Ok).execute()}();
